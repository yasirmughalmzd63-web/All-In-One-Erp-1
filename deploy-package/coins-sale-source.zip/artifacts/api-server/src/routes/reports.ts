import { Router } from "express";
import { and, desc, eq, gt, gte, inArray, lt, lte, sql } from "drizzle-orm";
import {
  db, locationsTable, accountsTable, productsTable,
  creditsTable, salesTable, saleItemsTable, purchasesTable, purchaseItemsTable,
  expensesTable, usersTable, auditLogsTable, stockTransfersTable,
  dollarWalletTable, customersTable,
} from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth.js";
import { tenantWhere } from "../lib/tenant.js";

const router = Router();
const EXCHANGE_RATE = 285;

// ─── helpers shared by financial reports ───────────────────────────────────
function parseDateRange(req: { query: Record<string, unknown> }): { start: Date; end: Date; allTime: boolean } {
  const startStr = typeof req.query.startDate === "string" ? req.query.startDate : null;
  const endStr   = typeof req.query.endDate   === "string" ? req.query.endDate   : null;
  const now = new Date();
  if (!startStr && !endStr) {
    return { start: new Date(0), end: new Date(now.getFullYear() + 100, 0, 1), allTime: true };
  }
  const todayStart = new Date(now); todayStart.setHours(0, 0, 0, 0);
  const todayEnd   = new Date(now); todayEnd.setHours(23, 59, 59, 999);
  const start = startStr ? new Date(`${startStr}T00:00:00.000`) : todayStart;
  const end   = endStr   ? new Date(`${endStr}T23:59:59.999`)   : todayEnd;
  return { start, end, allTime: false };
}

function readScope(req: { userId?: number | null; userRole?: string | null; userLocationId?: number | null; query: Record<string, unknown> }): {
  isAdmin: boolean; locationId: number | null; userId: number | null;
} | { error: { status: number; body: Record<string, unknown> } } {
  const isAdmin = req.userRole === "admin" || req.userRole === "manager";
  if (!isAdmin && (req.userLocationId === null || req.userLocationId === undefined)) {
    return { error: { status: 403, body: { error: "User has no assigned app/location; report access denied." } } };
  }
  const queryLoc = typeof req.query.locationId === "string" ? parseInt(req.query.locationId as string) : null;
  const locationId = isAdmin ? queryLoc : (req.userLocationId ?? null);
  return { isAdmin, locationId, userId: req.userId ?? null };
}

function localDayString(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

router.get("/reports/daily-snapshot", requireAuth, async (req, res): Promise<void> => {
  const today = new Date().toISOString().split("T")[0]!;

  const tAcc = tenantWhere(req, accountsTable.businessId);
  const tProd = tenantWhere(req, productsTable.businessId);
  const tCred = tenantWhere(req, creditsTable.businessId);
  const tSales = tenantWhere(req, salesTable.businessId);
  const tUsers = tenantWhere(req, usersTable.businessId);

  // ── Locations ─────────────────────────────────────────────────────────────
  const tLoc = tenantWhere(req, locationsTable.businessId);
  const locations = await db.select().from(locationsTable).where(and(eq(locationsTable.isActive, true), tLoc));

  // Bank per location
  const bankByLoc = await db.select({
    locationId: accountsTable.locationId,
    total: sql<string>`coalesce(sum(cast(${accountsTable.balance} as numeric)), 0)`,
  }).from(accountsTable).where(and(eq(accountsTable.isActive, true), tAcc)).groupBy(accountsTable.locationId);

  // Stock per location
  const stockByLoc = await db.select({
    locationId: productsTable.locationId,
    total: sql<string>`coalesce(sum(cast(${productsTable.costPrice} as numeric) * ${productsTable.stock}), 0)`,
    units: sql<string>`coalesce(sum(${productsTable.stock}), 0)`,
    products: sql<string>`count(*)`,
  }).from(productsTable).where(and(eq(productsTable.isActive, true), tProd)).groupBy(productsTable.locationId);

  // Credits – total receivable remaining (no location on credits, shown at totals level)
  const [creditRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${creditsTable.remainingAmount} as numeric)), 0)`,
  }).from(creditsTable).where(and(eq(creditsTable.type, "receivable"), tCred));

  // Unlinked (no location) bank + stock
  const bankMap = new Map(bankByLoc.map(r => [r.locationId ?? -1, parseFloat(r.total)]));
  const stockMap = new Map(stockByLoc.map(r => [r.locationId ?? -1, { value: parseFloat(r.total), units: parseInt(r.units), products: parseInt(r.products) }]));

  const locationData = locations.map(loc => {
    const bank  = bankMap.get(loc.id)  ?? 0;
    const stock = stockMap.get(loc.id) ?? { value: 0, units: 0, products: 0 };
    const total = bank + stock.value;
    return {
      id:         loc.id,
      name:       loc.name,
      address:    loc.address,
      bankPKR:    bank,
      stockPKR:   stock.value,
      stockUnits: stock.units,
      productCount: stock.products,
      totalPKR:   total,
      bankUSD:    bank / EXCHANGE_RATE,
      stockUSD:   stock.value / EXCHANGE_RATE,
      totalUSD:   total / EXCHANGE_RATE,
    };
  });

  // Unlinked totals
  const unlinkedBank  = bankMap.get(-1)  ?? 0;
  const unlinkedStock = stockMap.get(-1) ?? { value: 0, units: 0, products: 0 };

  // ── Users ─────────────────────────────────────────────────────────────────
  const users = await db.select().from(usersTable).where(and(eq(usersTable.isActive, true), tUsers));

  // Sales per user (today) — amountPaid = cash collected, credit = total - amountPaid
  const salesToday = await db.select({
    userId: salesTable.userId,
    total:  sql<string>`coalesce(sum(cast(${salesTable.total} as numeric)), 0)`,
    cash:   sql<string>`coalesce(sum(cast(${salesTable.amountPaid} as numeric)), 0)`,
    credit: sql<string>`coalesce(sum(greatest(cast(${salesTable.total} as numeric) - cast(${salesTable.amountPaid} as numeric), 0)), 0)`,
    count:  sql<string>`count(*)`,
  }).from(salesTable).where(and(sql`date(${salesTable.createdAt}) = ${today}`, tSales)).groupBy(salesTable.userId);

  // Sales all-time per user
  const salesAll = await db.select({
    userId: salesTable.userId,
    total:  sql<string>`coalesce(sum(cast(${salesTable.total} as numeric)), 0)`,
    cash:   sql<string>`coalesce(sum(cast(${salesTable.amountPaid} as numeric)), 0)`,
    credit: sql<string>`coalesce(sum(greatest(cast(${salesTable.total} as numeric) - cast(${salesTable.amountPaid} as numeric), 0)), 0)`,
    count:  sql<string>`count(*)`,
  }).from(salesTable).where(tSales).groupBy(salesTable.userId);

  const todayMap  = new Map(salesToday.map(r => [r.userId, r]));
  const allMap    = new Map(salesAll.map(r => [r.userId, r]));

  const userData = users.map(u => {
    const t = todayMap.get(u.id);
    const a = allMap.get(u.id);
    return {
      id:           u.id,
      name:         u.name,
      username:     u.username,
      role:         u.role,
      locationId:   u.locationId,
      today: {
        salesCount:  parseInt(t?.count ?? "0"),
        salesTotal:  parseFloat(t?.total ?? "0"),
        cashCollected: parseFloat(t?.cash ?? "0"),
        creditAmount:  parseFloat(t?.credit ?? "0"),
      },
      allTime: {
        salesCount:    parseInt(a?.count ?? "0"),
        salesTotal:    parseFloat(a?.total ?? "0"),
        cashCollected: parseFloat(a?.cash ?? "0"),
        creditAmount:  parseFloat(a?.credit ?? "0"),
      },
    };
  });

  // ── Grand Totals ──────────────────────────────────────────────────────────
  const totalBank  = locationData.reduce((s, l) => s + l.bankPKR,  0) + unlinkedBank;
  const totalStock = locationData.reduce((s, l) => s + l.stockPKR, 0) + unlinkedStock.value;
  const totalCredit = parseFloat(creditRow?.total ?? "0");
  const grandTotal  = totalBank + totalStock + totalCredit;

  res.json({
    generatedAt:  new Date().toISOString(),
    date:         today,
    exchangeRate: EXCHANGE_RATE,
    totals: {
      bankPKR:    totalBank,
      stockPKR:   totalStock,
      creditPKR:  totalCredit,
      grandPKR:   grandTotal,
      bankUSD:    totalBank   / EXCHANGE_RATE,
      stockUSD:   totalStock  / EXCHANGE_RATE,
      creditUSD:  totalCredit / EXCHANGE_RATE,
      grandUSD:   grandTotal  / EXCHANGE_RATE,
      unlinkedBankPKR:  unlinkedBank,
      unlinkedStockPKR: unlinkedStock.value,
      unlinkedStockUnits: unlinkedStock.units,
    },
    locations: locationData,
    users: userData,
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// PROFIT & LOSS  GET /api/reports/profit-loss?startDate&endDate&locationId
// Sales − COGS − Expenses = Net Profit
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/profit-loss", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }
  const { start, end, allTime } = parseDateRange(req as never);

  // Sales total + count
  const salesConds = [gte(salesTable.createdAt, start), lte(salesTable.createdAt, end), tenantWhere(req, salesTable.businessId)];
  if (scope.locationId) salesConds.push(eq(salesTable.locationId, scope.locationId));
  const [salesRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${salesTable.total} as numeric)), 0)`,
    count: sql<string>`count(*)`,
    discount: sql<string>`coalesce(sum(cast(${salesTable.discount} as numeric)), 0)`,
    paid: sql<string>`coalesce(sum(cast(${salesTable.amountPaid} as numeric)), 0)`,
  }).from(salesTable).where(and(...salesConds));

  // COGS = sum(saleItems.qty * product.cost_price) — for sales in range, scoped by location
  const cogsRows = await db.select({
    qty: sql<string>`coalesce(sum(${saleItemsTable.qty}), 0)`,
    cogs: sql<string>`coalesce(sum(${saleItemsTable.qty} * cast(${productsTable.costPrice} as numeric)), 0)`,
  }).from(saleItemsTable)
    .innerJoin(salesTable, eq(saleItemsTable.saleId, salesTable.id))
    .innerJoin(productsTable, eq(saleItemsTable.productId, productsTable.id))
    .where(and(...salesConds));

  // Purchases (informational)
  const purchaseConds = [gte(purchasesTable.createdAt, start), lte(purchasesTable.createdAt, end), tenantWhere(req, purchasesTable.businessId)];
  if (scope.locationId) purchaseConds.push(eq(purchasesTable.locationId, scope.locationId));
  const [purRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${purchasesTable.total} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(purchasesTable).where(and(...purchaseConds));

  // Expenses by date (uses expenses.date YYYY-MM-DD)
  const startDay = localDayString(start);
  const endDay   = localDayString(end);
  const expenseConds = allTime ? [tenantWhere(req, expensesTable.businessId)] : [gte(expensesTable.date, startDay), lte(expensesTable.date, endDay), tenantWhere(req, expensesTable.businessId)];
  const [expRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${expensesTable.amount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(expensesTable).where(and(...expenseConds));

  // Per-category expense breakdown
  const expByCategory = await db.select({
    categoryId: expensesTable.categoryId,
    title: expensesTable.title,
    total: sql<string>`coalesce(sum(cast(${expensesTable.amount} as numeric)), 0)`,
  }).from(expensesTable).where(and(...expenseConds)).groupBy(expensesTable.categoryId, expensesTable.title);

  const sales    = parseFloat(salesRow?.total ?? "0");
  const cogs     = parseFloat(cogsRows[0]?.cogs ?? "0");
  const expenses = parseFloat(expRow?.total ?? "0");
  const purchase = parseFloat(purRow?.total ?? "0");
  const grossProfit = sales - cogs;
  const netProfit   = grossProfit - expenses;
  const margin = sales > 0 ? (netProfit / sales) * 100 : 0;

  res.json({
    startDate: start.toISOString(), endDate: end.toISOString(), allTime,
    scope,
    sales: {
      total: sales.toFixed(8),
      count: parseInt(salesRow?.count ?? "0"),
      discount: parseFloat(salesRow?.discount ?? "0").toFixed(8),
      collected: parseFloat(salesRow?.paid ?? "0").toFixed(8),
    },
    cogs: { total: cogs.toFixed(8), unitsSold: parseInt(cogsRows[0]?.qty ?? "0") },
    purchases: { total: purchase.toFixed(8), count: parseInt(purRow?.count ?? "0") },
    expenses: {
      total: expenses.toFixed(8),
      count: parseInt(expRow?.count ?? "0"),
      breakdown: expByCategory.map(c => ({
        categoryId: c.categoryId, title: c.title, total: parseFloat(c.total).toFixed(8),
      })).sort((a, b) => parseFloat(b.total) - parseFloat(a.total)),
    },
    grossProfit: grossProfit.toFixed(8),
    netProfit:   netProfit.toFixed(8),
    margin:      margin.toFixed(2),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// BALANCE SHEET  GET /api/reports/balance-sheet?asOfDate&locationId
// Snapshot: Assets = Liabilities + Equity (Equity is plugged from net = A − L)
// Note: Uses CURRENT account balances and product stock; historical asOfDate
// for receivables/payables uses snapshot of credits.remainingAmount as of now.
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/balance-sheet", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }

  // Accounts — buckets by type
  const accConds = [eq(accountsTable.isActive, true), tenantWhere(req, accountsTable.businessId)];
  if (scope.locationId) accConds.push(eq(accountsTable.locationId, scope.locationId));
  const accounts = await db.select().from(accountsTable).where(and(...accConds));
  const cash = accounts.filter(a => (a.type ?? "cash") === "cash").reduce((s, a) => s + parseFloat(a.balance), 0);
  const bank = accounts.filter(a => a.type === "bank").reduce((s, a) => s + parseFloat(a.balance), 0);
  const wallet = accounts.filter(a => a.type === "mobile_wallet").reduce((s, a) => s + parseFloat(a.balance), 0);
  const otherAcc = accounts.filter(a => !["cash", "bank", "mobile_wallet"].includes(a.type ?? "cash")).reduce((s, a) => s + parseFloat(a.balance), 0);

  // Inventory at cost
  const prodConds = [eq(productsTable.isActive, true), tenantWhere(req, productsTable.businessId)];
  if (scope.locationId) prodConds.push(eq(productsTable.locationId, scope.locationId));
  const [invRow] = await db.select({
    value: sql<string>`coalesce(sum(${productsTable.stock} * cast(${productsTable.costPrice} as numeric)), 0)`,
    valueAtPrice: sql<string>`coalesce(sum(${productsTable.stock} * cast(${productsTable.unitPrice} as numeric)), 0)`,
    units: sql<string>`coalesce(sum(${productsTable.stock}), 0)`,
  }).from(productsTable).where(and(...prodConds));

  // Receivables / Payables — scope by userId for non-admin (credits.userId = creator)
  const recConds = [eq(creditsTable.type, "receivable"), tenantWhere(req, creditsTable.businessId)];
  const payConds = [eq(creditsTable.type, "payable"), tenantWhere(req, creditsTable.businessId)];
  if (!scope.isAdmin && scope.userId) {
    recConds.push(eq(creditsTable.userId, scope.userId));
    payConds.push(eq(creditsTable.userId, scope.userId));
  }
  const [recRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${creditsTable.remainingAmount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(creditsTable).where(and(...recConds));
  const [payRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${creditsTable.remainingAmount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(creditsTable).where(and(...payConds));

  const inventoryValue = parseFloat(invRow?.value ?? "0");
  const receivables    = parseFloat(recRow?.total ?? "0");
  const payables       = parseFloat(payRow?.total ?? "0");

  const totalAssets = cash + bank + wallet + otherAcc + inventoryValue + receivables;
  const totalLiabilities = payables;
  const equity = totalAssets - totalLiabilities;

  res.json({
    asOfDate: new Date().toISOString(),
    scope,
    assets: {
      cash:  cash.toFixed(8),
      bank:  bank.toFixed(8),
      mobileWallet: wallet.toFixed(8),
      otherAccounts: otherAcc.toFixed(8),
      inventory: inventoryValue.toFixed(8),
      inventoryAtPrice: parseFloat(invRow?.valueAtPrice ?? "0").toFixed(8),
      inventoryUnits: parseInt(invRow?.units ?? "0"),
      receivables: receivables.toFixed(8),
      receivablesCount: parseInt(recRow?.count ?? "0"),
      total: totalAssets.toFixed(8),
    },
    liabilities: {
      payables: payables.toFixed(8),
      payablesCount: parseInt(payRow?.count ?? "0"),
      loans: "0.00000000",
      total: totalLiabilities.toFixed(8),
    },
    equity: {
      ownerCapitalAndProfit: equity.toFixed(8),
      total: equity.toFixed(8),
    },
    accounts: accounts.map(a => ({ ...a, createdAt: a.createdAt.toISOString(), updatedAt: a.updatedAt.toISOString() })),
    balanceCheck: { liabilitiesPlusEquity: (totalLiabilities + equity).toFixed(8), matches: true },
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCT-WISE PROFIT  GET /api/reports/product-profit?startDate&endDate&locationId
// Per product: opening / purchased / sold / balance / value / profit
// Profit = sum(saleItems.total) - sum(saleItems.qty * cost_price)  [in range]
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/product-profit", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }
  const { start, end } = parseDateRange(req as never);

  const prodConds = [eq(productsTable.isActive, true), tenantWhere(req, productsTable.businessId)];
  if (scope.locationId) prodConds.push(eq(productsTable.locationId, scope.locationId));
  const products = await db.select({
    id: productsTable.id, name: productsTable.name,
    stock: productsTable.stock, unitPrice: productsTable.unitPrice, costPrice: productsTable.costPrice,
    locationId: productsTable.locationId,
  }).from(productsTable).where(and(...prodConds));
  const productIds = products.map(p => p.id);

  if (productIds.length === 0) { res.json({ rows: [], totals: emptyProductTotals(), scope, startDate: start.toISOString(), endDate: end.toISOString() }); return; }

  const locations = await db.select({ id: locationsTable.id, name: locationsTable.name }).from(locationsTable).where(tenantWhere(req, locationsTable.businessId));
  const locName = new Map(locations.map(l => [l.id, l.name]));

  const inSales = await db.select({
    productId: saleItemsTable.productId,
    qty: sql<string>`coalesce(sum(${saleItemsTable.qty}), 0)`,
    revenue: sql<string>`coalesce(sum(cast(${saleItemsTable.total} as numeric)), 0)`,
    cogs: sql<string>`coalesce(sum(${saleItemsTable.qty} * cast(${productsTable.costPrice} as numeric)), 0)`,
  }).from(saleItemsTable)
    .innerJoin(salesTable, eq(saleItemsTable.saleId, salesTable.id))
    .innerJoin(productsTable, eq(saleItemsTable.productId, productsTable.id))
    .where(and(inArray(saleItemsTable.productId, productIds), gte(salesTable.createdAt, start), lte(salesTable.createdAt, end)))
    .groupBy(saleItemsTable.productId);

  const inPur = await db.select({
    productId: purchaseItemsTable.productId,
    qty: sql<string>`coalesce(sum(${purchaseItemsTable.qty}), 0)`,
    cost: sql<string>`coalesce(sum(cast(${purchaseItemsTable.total} as numeric)), 0)`,
  }).from(purchaseItemsTable)
    .innerJoin(purchasesTable, eq(purchaseItemsTable.purchaseId, purchasesTable.id))
    .where(and(inArray(purchaseItemsTable.productId, productIds), gte(purchasesTable.createdAt, start), lte(purchasesTable.createdAt, end)))
    .groupBy(purchaseItemsTable.productId);

  const afterSales = await db.select({
    productId: saleItemsTable.productId, qty: sql<string>`coalesce(sum(${saleItemsTable.qty}), 0)`,
  }).from(saleItemsTable).innerJoin(salesTable, eq(saleItemsTable.saleId, salesTable.id))
    .where(and(inArray(saleItemsTable.productId, productIds), gt(salesTable.createdAt, end)))
    .groupBy(saleItemsTable.productId);

  const afterPur = await db.select({
    productId: purchaseItemsTable.productId, qty: sql<string>`coalesce(sum(${purchaseItemsTable.qty}), 0)`,
  }).from(purchaseItemsTable).innerJoin(purchasesTable, eq(purchaseItemsTable.purchaseId, purchasesTable.id))
    .where(and(inArray(purchaseItemsTable.productId, productIds), gt(purchasesTable.createdAt, end)))
    .groupBy(purchaseItemsTable.productId);

  const sMap = new Map(inSales.map(r => [r.productId, { qty: parseInt(r.qty), revenue: parseFloat(r.revenue), cogs: parseFloat(r.cogs) }]));
  const pMap = new Map(inPur.map(r => [r.productId, { qty: parseInt(r.qty), cost: parseFloat(r.cost) }]));
  const aSMap = new Map(afterSales.map(r => [r.productId, parseInt(r.qty)]));
  const aPMap = new Map(afterPur.map(r => [r.productId, parseInt(r.qty)]));

  const rows = products.map(p => {
    const s = sMap.get(p.id) ?? { qty: 0, revenue: 0, cogs: 0 };
    const pu = pMap.get(p.id) ?? { qty: 0, cost: 0 };
    const balance = (p.stock ?? 0) - (aPMap.get(p.id) ?? 0) + (aSMap.get(p.id) ?? 0);
    const opening = balance - pu.qty + s.qty;
    const profit = s.revenue - s.cogs;
    return {
      productId: p.id, productName: p.name,
      locationId: p.locationId, locationName: p.locationId ? (locName.get(p.locationId) ?? null) : null,
      opening, purchased: pu.qty, purchasedValue: pu.cost.toFixed(8),
      sold: s.qty, revenue: s.revenue.toFixed(8), cogs: s.cogs.toFixed(8),
      balance, balanceValue: (balance * parseFloat(p.costPrice ?? "0")).toFixed(8),
      profit: profit.toFixed(8),
      margin: s.revenue > 0 ? ((profit / s.revenue) * 100).toFixed(2) : "0.00",
    };
  }).sort((a, b) => parseFloat(b.profit) - parseFloat(a.profit));

  const totals = rows.reduce((acc, r) => ({
    opening: acc.opening + r.opening,
    purchased: acc.purchased + r.purchased, purchasedValue: acc.purchasedValue + parseFloat(r.purchasedValue),
    sold: acc.sold + r.sold, revenue: acc.revenue + parseFloat(r.revenue), cogs: acc.cogs + parseFloat(r.cogs),
    balance: acc.balance + r.balance, balanceValue: acc.balanceValue + parseFloat(r.balanceValue),
    profit: acc.profit + parseFloat(r.profit),
  }), { opening: 0, purchased: 0, purchasedValue: 0, sold: 0, revenue: 0, cogs: 0, balance: 0, balanceValue: 0, profit: 0 });

  res.json({
    startDate: start.toISOString(), endDate: end.toISOString(),
    scope,
    rows,
    totals: {
      opening: totals.opening, purchased: totals.purchased, purchasedValue: totals.purchasedValue.toFixed(8),
      sold: totals.sold, revenue: totals.revenue.toFixed(8), cogs: totals.cogs.toFixed(8),
      balance: totals.balance, balanceValue: totals.balanceValue.toFixed(8),
      profit: totals.profit.toFixed(8),
      margin: totals.revenue > 0 ? ((totals.profit / totals.revenue) * 100).toFixed(2) : "0.00",
    },
  });
});
function emptyProductTotals() {
  return { opening: 0, purchased: 0, purchasedValue: "0.00000000", sold: 0, revenue: "0.00000000", cogs: "0.00000000",
    balance: 0, balanceValue: "0.00000000", profit: "0.00000000", margin: "0.00" };
}

// ─────────────────────────────────────────────────────────────────────────────
// LOCATION-WISE  GET /api/reports/location-summary?startDate&endDate
// Per location: sales / purchases / stock value / cash balance / profit
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/location-summary", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }
  const { start, end } = parseDateRange(req as never);

  const locWhere = scope.locationId ? eq(locationsTable.id, scope.locationId) : sql`true`;
  const locations = await db.select().from(locationsTable).where(and(eq(locationsTable.isActive, true), locWhere, tenantWhere(req, locationsTable.businessId)));

  const tSales = tenantWhere(req, salesTable.businessId);
  const tPurs = tenantWhere(req, purchasesTable.businessId);
  const tProd = tenantWhere(req, productsTable.businessId);
  const tAcc = tenantWhere(req, accountsTable.businessId);

  // Aggregations per location
  const salesByLoc = await db.select({
    locationId: salesTable.locationId,
    total: sql<string>`coalesce(sum(cast(${salesTable.total} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(salesTable).where(and(gte(salesTable.createdAt, start), lte(salesTable.createdAt, end), tSales)).groupBy(salesTable.locationId);

  const purByLoc = await db.select({
    locationId: purchasesTable.locationId,
    total: sql<string>`coalesce(sum(cast(${purchasesTable.total} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(purchasesTable).where(and(gte(purchasesTable.createdAt, start), lte(purchasesTable.createdAt, end), tPurs)).groupBy(purchasesTable.locationId);

  // COGS per location
  const cogsByLoc = await db.select({
    locationId: salesTable.locationId,
    cogs: sql<string>`coalesce(sum(${saleItemsTable.qty} * cast(${productsTable.costPrice} as numeric)), 0)`,
  }).from(saleItemsTable)
    .innerJoin(salesTable, eq(saleItemsTable.saleId, salesTable.id))
    .innerJoin(productsTable, eq(saleItemsTable.productId, productsTable.id))
    .where(and(gte(salesTable.createdAt, start), lte(salesTable.createdAt, end), tSales)).groupBy(salesTable.locationId);

  const stockByLoc = await db.select({
    locationId: productsTable.locationId,
    value: sql<string>`coalesce(sum(${productsTable.stock} * cast(${productsTable.costPrice} as numeric)), 0)`,
    units: sql<string>`coalesce(sum(${productsTable.stock}), 0)`,
  }).from(productsTable).where(and(eq(productsTable.isActive, true), tProd)).groupBy(productsTable.locationId);

  const cashByLoc = await db.select({
    locationId: accountsTable.locationId,
    total: sql<string>`coalesce(sum(cast(${accountsTable.balance} as numeric)), 0)`,
  }).from(accountsTable).where(and(eq(accountsTable.isActive, true), tAcc)).groupBy(accountsTable.locationId);

  const sMap = new Map(salesByLoc.map(r => [r.locationId ?? -1, { total: parseFloat(r.total), count: parseInt(r.count) }]));
  const pMap = new Map(purByLoc.map(r => [r.locationId ?? -1, { total: parseFloat(r.total), count: parseInt(r.count) }]));
  const cogsMap = new Map(cogsByLoc.map(r => [r.locationId ?? -1, parseFloat(r.cogs)]));
  const stMap = new Map(stockByLoc.map(r => [r.locationId ?? -1, { value: parseFloat(r.value), units: parseInt(r.units) }]));
  const csMap = new Map(cashByLoc.map(r => [r.locationId ?? -1, parseFloat(r.total)]));

  const rows = locations.map(l => {
    const s = sMap.get(l.id) ?? { total: 0, count: 0 };
    const p = pMap.get(l.id) ?? { total: 0, count: 0 };
    const cogs = cogsMap.get(l.id) ?? 0;
    const stock = stMap.get(l.id) ?? { value: 0, units: 0 };
    const cash = csMap.get(l.id) ?? 0;
    return {
      locationId: l.id, locationName: l.name,
      sales: s.total.toFixed(8), salesCount: s.count,
      purchases: p.total.toFixed(8), purchasesCount: p.count,
      cogs: cogs.toFixed(8),
      grossProfit: (s.total - cogs).toFixed(8),
      stockValue: stock.value.toFixed(8), stockUnits: stock.units,
      cashBalance: cash.toFixed(8),
      netWorth: (cash + stock.value).toFixed(8),
    };
  }).sort((a, b) => parseFloat(b.sales) - parseFloat(a.sales));

  const totals = rows.reduce((acc, r) => ({
    sales: acc.sales + parseFloat(r.sales), purchases: acc.purchases + parseFloat(r.purchases),
    cogs: acc.cogs + parseFloat(r.cogs), grossProfit: acc.grossProfit + parseFloat(r.grossProfit),
    stockValue: acc.stockValue + parseFloat(r.stockValue), cashBalance: acc.cashBalance + parseFloat(r.cashBalance),
    netWorth: acc.netWorth + parseFloat(r.netWorth),
  }), { sales: 0, purchases: 0, cogs: 0, grossProfit: 0, stockValue: 0, cashBalance: 0, netWorth: 0 });

  res.json({
    startDate: start.toISOString(), endDate: end.toISOString(), scope,
    rows,
    totals: {
      sales: totals.sales.toFixed(8), purchases: totals.purchases.toFixed(8),
      cogs: totals.cogs.toFixed(8), grossProfit: totals.grossProfit.toFixed(8),
      stockValue: totals.stockValue.toFixed(8), cashBalance: totals.cashBalance.toFixed(8),
      netWorth: totals.netWorth.toFixed(8),
    },
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// CASH FLOW  GET /api/reports/cash-flow?accountId&startDate&endDate
// Movements per account: opening, credits (in), debits (out), closing
// "Credits" = sales.amountPaid where account, "Debits" = expenses.amount + purchases.amountPaid
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/cash-flow", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }
  const { start, end } = parseDateRange(req as never);
  const queryAccId = typeof req.query.accountId === "string" ? parseInt(req.query.accountId) : null;

  const accConds = [eq(accountsTable.isActive, true), tenantWhere(req, accountsTable.businessId)];
  if (scope.locationId) accConds.push(eq(accountsTable.locationId, scope.locationId));
  if (queryAccId)       accConds.push(eq(accountsTable.id, queryAccId));
  const accounts = await db.select().from(accountsTable).where(and(...accConds));
  const accountIds = accounts.map(a => a.id);

  if (accountIds.length === 0) { res.json({ rows: [], totals: { credits: "0.00000000", debits: "0.00000000", net: "0.00000000", closing: "0.00000000" }, scope }); return; }

  // Sales-in-range cash IN (amountPaid)
  const salesIn = await db.select({
    accountId: salesTable.accountId,
    total: sql<string>`coalesce(sum(cast(${salesTable.amountPaid} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(salesTable).where(and(inArray(salesTable.accountId, accountIds), gte(salesTable.createdAt, start), lte(salesTable.createdAt, end), tenantWhere(req, salesTable.businessId))).groupBy(salesTable.accountId);

  // Purchases cash OUT
  const pursOut = await db.select({
    accountId: purchasesTable.accountId,
    total: sql<string>`coalesce(sum(cast(${purchasesTable.amountPaid} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(purchasesTable).where(and(inArray(purchasesTable.accountId, accountIds), gte(purchasesTable.createdAt, start), lte(purchasesTable.createdAt, end), tenantWhere(req, purchasesTable.businessId))).groupBy(purchasesTable.accountId);

  // Expenses cash OUT (date col is text YYYY-MM-DD)
  const startDay = localDayString(start);
  const endDay   = localDayString(end);
  const expOut = await db.select({
    accountId: expensesTable.accountId,
    total: sql<string>`coalesce(sum(cast(${expensesTable.amount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(expensesTable).where(and(inArray(expensesTable.accountId, accountIds), gte(expensesTable.date, startDay), lte(expensesTable.date, endDay), tenantWhere(req, expensesTable.businessId))).groupBy(expensesTable.accountId);

  const sMap = new Map(salesIn.map(r => [r.accountId ?? -1, { total: parseFloat(r.total), count: parseInt(r.count) }]));
  const pMap = new Map(pursOut.map(r => [r.accountId ?? -1, { total: parseFloat(r.total), count: parseInt(r.count) }]));
  const eMap = new Map(expOut.map(r => [r.accountId ?? -1, { total: parseFloat(r.total), count: parseInt(r.count) }]));

  const rows = accounts.map(a => {
    const credIn = sMap.get(a.id) ?? { total: 0, count: 0 };
    const debOutP = pMap.get(a.id) ?? { total: 0, count: 0 };
    const debOutE = eMap.get(a.id) ?? { total: 0, count: 0 };
    const credits = credIn.total;
    const debits  = debOutP.total + debOutE.total;
    const closing = parseFloat(a.balance);   // current balance is closing
    const opening = closing - credits + debits;
    return {
      accountId: a.id, accountName: a.name, accountType: a.type, currency: a.currency,
      opening: opening.toFixed(8),
      credits: credits.toFixed(8), creditsCount: credIn.count,
      debitsPurchases: debOutP.total.toFixed(8), debitsExpenses: debOutE.total.toFixed(8),
      debits: debits.toFixed(8), debitsCount: debOutP.count + debOutE.count,
      net: (credits - debits).toFixed(8),
      closing: closing.toFixed(8),
    };
  }).sort((a, b) => parseFloat(b.closing) - parseFloat(a.closing));

  const t = rows.reduce((acc, r) => ({
    credits: acc.credits + parseFloat(r.credits),
    debits:  acc.debits  + parseFloat(r.debits),
    closing: acc.closing + parseFloat(r.closing),
    opening: acc.opening + parseFloat(r.opening),
  }), { credits: 0, debits: 0, closing: 0, opening: 0 });

  res.json({
    startDate: start.toISOString(), endDate: end.toISOString(), scope,
    rows,
    totals: {
      opening: t.opening.toFixed(8),
      credits: t.credits.toFixed(8), debits: t.debits.toFixed(8),
      net: (t.credits - t.debits).toFixed(8),
      closing: t.closing.toFixed(8),
    },
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// AUDIT & CONTROL  GET /api/reports/audit-checks
// Surfaces anomalies: negative stock, sales without payment, large pending,
// last cash count diffs, recent destructive audit log entries.
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/audit-checks", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }

  const prodConds = [eq(productsTable.isActive, true), tenantWhere(req, productsTable.businessId)];
  if (scope.locationId) prodConds.push(eq(productsTable.locationId, scope.locationId));

  // Negative stock products (stock < 0 = shortage)
  // The join is tenant-scoped on the ON clause so a cross-tenant locationId
  // on a product row can never surface another business's location name.
  const negStock = await db.select({
    id: productsTable.id,
    name: productsTable.name,
    stock: productsTable.stock,
    unitPrice: productsTable.unitPrice,
    costPrice: productsTable.costPrice,
    locationId: productsTable.locationId,
    locationName: locationsTable.name,
  }).from(productsTable)
    .leftJoin(
      locationsTable,
      and(
        eq(productsTable.locationId, locationsTable.id),
        tenantWhere(req, locationsTable.businessId),
      ),
    )
    .where(and(...prodConds, lt(productsTable.stock, 0)));

  // Zero-stock active products (potential lost-sale alert) — same tenant-scoped join
  const zeroStock = await db.select({
    id: productsTable.id,
    name: productsTable.name,
    locationId: productsTable.locationId,
    locationName: locationsTable.name,
  }).from(productsTable)
    .leftJoin(
      locationsTable,
      and(
        eq(productsTable.locationId, locationsTable.id),
        tenantWhere(req, locationsTable.businessId),
      ),
    )
    .where(and(...prodConds, eq(productsTable.stock, 0)));

  // Sales with credit (amountPaid < total)
  const salesConds = [sql`cast(${salesTable.amountPaid} as numeric) < cast(${salesTable.total} as numeric)`, tenantWhere(req, salesTable.businessId)];
  if (scope.locationId) salesConds.push(eq(salesTable.locationId, scope.locationId));
  const unpaidSales = await db.select({
    id: salesTable.id, invoiceNo: salesTable.invoiceNo,
    total: salesTable.total, amountPaid: salesTable.amountPaid,
    createdAt: salesTable.createdAt, customerId: salesTable.customerId, locationId: salesTable.locationId,
  }).from(salesTable).where(and(...salesConds)).orderBy(desc(salesTable.createdAt)).limit(50);

  // Outstanding receivables/payables — scoped by userId for non-admin
  const recConds = [eq(creditsTable.type, "receivable"), tenantWhere(req, creditsTable.businessId)];
  const payConds = [eq(creditsTable.type, "payable"), tenantWhere(req, creditsTable.businessId)];
  if (!scope.isAdmin && scope.userId) {
    recConds.push(eq(creditsTable.userId, scope.userId));
    payConds.push(eq(creditsTable.userId, scope.userId));
  }
  const [recRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${creditsTable.remainingAmount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(creditsTable).where(and(...recConds));

  const [payRow] = await db.select({
    total: sql<string>`coalesce(sum(cast(${creditsTable.remainingAmount} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(creditsTable).where(and(...payConds));

  // Recent destructive audit log entries — scoped by userId for non-admin
  const delConds = [sql`lower(${auditLogsTable.action}) like '%delete%'`, tenantWhere(req, auditLogsTable.businessId)];
  if (!scope.isAdmin && scope.userId) {
    delConds.push(eq(auditLogsTable.userId, scope.userId));
  }
  const deletions = await db.select({
    id: auditLogsTable.id, userId: auditLogsTable.userId, action: auditLogsTable.action,
    entityType: auditLogsTable.entityType, entityId: auditLogsTable.entityId,
    details: auditLogsTable.details, createdAt: auditLogsTable.createdAt,
  }).from(auditLogsTable)
    .where(and(...delConds))
    .orderBy(desc(auditLogsTable.createdAt)).limit(20);

  // Unified summary table: ID · Name · App · Short · Excess · Remarks
  // Short  = how many units we are negative (deficit)
  // Excess = currently 0 (reserved for future "system stock vs physical count" comparison)
  // Items are sorted: shortages first (most severe), then out-of-stock
  type SummaryRow = {
    id: number; name: string; app: string;
    short: number; shortValue: string;
    excess: number; excessValue: string;
    remarks: string;
  };
  const summary: SummaryRow[] = [];
  for (const p of negStock) {
    const shortQty = Math.abs(p.stock);
    const unit = parseFloat(p.unitPrice ?? "0");
    summary.push({
      id: p.id,
      name: p.name,
      app: p.locationName ?? "—",
      short: shortQty,
      shortValue: (shortQty * unit).toFixed(2),
      excess: 0,
      excessValue: "0.00",
      remarks: `Negative stock — sold ${shortQty.toLocaleString()} more than available`,
    });
  }
  for (const p of zeroStock) {
    summary.push({
      id: p.id,
      name: p.name,
      app: p.locationName ?? "—",
      short: 0,
      shortValue: "0.00",
      excess: 0,
      excessValue: "0.00",
      remarks: "Out of stock — restock recommended",
    });
  }

  res.json({
    generatedAt: new Date().toISOString(),
    scope,
    summary,
    summaryCount: summary.length,
    negativeStock: { count: negStock.length, items: negStock },
    zeroStock:     { count: zeroStock.length, items: zeroStock.slice(0, 50) },
    unpaidSales:   {
      count: unpaidSales.length,
      items: unpaidSales.map(s => ({ ...s, createdAt: s.createdAt.toISOString(), pending: (parseFloat(s.total) - parseFloat(s.amountPaid)).toFixed(8) })),
    },
    receivables: { total: recRow?.total ?? "0", count: parseInt(recRow?.count ?? "0") },
    payables:    { total: payRow?.total ?? "0", count: parseInt(payRow?.count ?? "0") },
    recentDeletions: deletions.map(d => ({ ...d, createdAt: d.createdAt.toISOString() })),
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// EMPLOYEE RECONCILIATION  GET /api/reports/employee-reconciliation
// Per-user breakdown of sales activity for Today, Yesterday, and Lifetime.
// Used by the More → Reconciliation screen.
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/employee-reconciliation", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }

  // Date boundaries in server local time (matches dashboard.ts convention).
  // We use Date objects with gte/lt rather than `date(createdAt) = 'YYYY-MM-DD'`
  // so timezone semantics are identical to the dashboard's daily totals.
  const now = new Date();
  const todayStart = new Date(now);     todayStart.setHours(0, 0, 0, 0);
  const tomorrowStart = new Date(todayStart); tomorrowStart.setDate(tomorrowStart.getDate() + 1);
  const yesterdayStart = new Date(todayStart); yesterdayStart.setDate(yesterdayStart.getDate() - 1);
  const todayStr     = localDayString(todayStart);
  const yesterdayStr = localDayString(yesterdayStart);

  const tUsers = tenantWhere(req, usersTable.businessId);
  const tSales = tenantWhere(req, salesTable.businessId);

  // Active users in this tenant (optionally filtered by location for non-admins)
  const userConds = [eq(usersTable.isActive, true), tUsers];
  if (scope.locationId) userConds.push(eq(usersTable.locationId, scope.locationId));
  const users = await db.select({
    id: usersTable.id,
    name: usersTable.name,
    username: usersTable.username,
    role: usersTable.role,
    locationId: usersTable.locationId,
  }).from(usersTable).where(and(...userConds));

  if (users.length === 0) {
    res.json({
      generatedAt: now.toISOString(),
      scope,
      today: todayStr,
      yesterday: yesterdayStr,
      rows: [],
      totals: {
        today:     { count: 0, total: "0.00", cash: "0.00" },
        yesterday: { count: 0, total: "0.00", cash: "0.00" },
        lifetime:  { count: 0, total: "0.00", cash: "0.00" },
      },
    });
    return;
  }

  // Build sales aggregation for a date condition (or null = lifetime)
  const baseSalesConds = [tSales];
  if (scope.locationId) baseSalesConds.push(eq(salesTable.locationId, scope.locationId));

  type Bucket = Record<number, { count: number; total: number; cash: number }>;
  async function aggregate(extraDateCond: ReturnType<typeof sql> | null): Promise<Bucket> {
    const conds = [...baseSalesConds];
    if (extraDateCond) conds.push(extraDateCond);
    const rows = await db.select({
      userId: salesTable.userId,
      count:  sql<string>`count(*)`,
      total:  sql<string>`coalesce(sum(cast(${salesTable.total} as numeric)), 0)`,
      cash:   sql<string>`coalesce(sum(cast(${salesTable.amountPaid} as numeric)), 0)`,
    }).from(salesTable).where(and(...conds)).groupBy(salesTable.userId);
    const map: Bucket = {};
    for (const r of rows) {
      map[r.userId] = {
        count: parseInt(r.count, 10),
        total: parseFloat(r.total),
        cash:  parseFloat(r.cash),
      };
    }
    return map;
  }

  const [todayMap, yesterdayMap, lifetimeMap] = await Promise.all([
    aggregate(and(gte(salesTable.createdAt, todayStart),     lt(salesTable.createdAt, tomorrowStart))!),
    aggregate(and(gte(salesTable.createdAt, yesterdayStart), lt(salesTable.createdAt, todayStart))!),
    aggregate(null),
  ]);

  const blank = { count: 0, total: 0, cash: 0 };
  const rows = users.map(u => {
    const t = todayMap[u.id]     ?? blank;
    const y = yesterdayMap[u.id] ?? blank;
    const l = lifetimeMap[u.id]  ?? blank;
    return {
      userId: u.id,
      name: u.name,
      username: u.username,
      role: u.role,
      locationId: u.locationId,
      today:     { count: t.count, total: t.total.toFixed(2), cash: t.cash.toFixed(2) },
      yesterday: { count: y.count, total: y.total.toFixed(2), cash: y.cash.toFixed(2) },
      lifetime:  { count: l.count, total: l.total.toFixed(2), cash: l.cash.toFixed(2) },
    };
  })
  // Surface most-active users first (lifetime sales count desc, then name)
  .sort((a, b) => (b.lifetime.count - a.lifetime.count) || a.name.localeCompare(b.name));

  // Grand totals (across all users in scope)
  const sumBucket = (bucket: Bucket) => {
    let count = 0, total = 0, cash = 0;
    for (const v of Object.values(bucket)) { count += v.count; total += v.total; cash += v.cash; }
    return { count, total: total.toFixed(2), cash: cash.toFixed(2) };
  };

  res.json({
    generatedAt: now.toISOString(),
    scope,
    today: todayStr,
    yesterday: yesterdayStr,
    rows,
    totals: {
      today:     sumBucket(todayMap),
      yesterday: sumBucket(yesterdayMap),
      lifetime:  sumBucket(lifetimeMap),
    },
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOMER DOLLAR REPORT  GET /api/reports/customer-dollar-report
// Per customer: USD received / products sent / net balance — period + lifetime
// ─────────────────────────────────────────────────────────────────────────────
const USD_IN_TYPES  = ["received", "partial", "recovery", "purchase"];
const USD_OUT_TYPES = ["product", "topup"];

router.get("/reports/customer-dollar-report", requireAuth, async (req, res): Promise<void> => {
  const { start, end, allTime } = parseDateRange(req as never);

  // All customers
  const customers = await db.select({ id: customersTable.id, name: customersTable.name, phone: customersTable.phone })
    .from(customersTable)
    .where(tenantWhere(req, customersTable.businessId));

  if (customers.length === 0) {
    res.json({ customers: [], totals: { periodUsdIn: "0", periodUsdOut: "0", periodNet: "0", lifetimeUsdIn: "0", lifetimeUsdOut: "0", lifetimeNet: "0" }, startDate: start.toISOString(), endDate: end.toISOString(), allTime });
    return;
  }

  const customerIds = customers.map(c => c.id);

  // Period aggregation per customer
  const periodConds = [eq(dollarWalletTable.partyType, "customer"), inArray(dollarWalletTable.partyId, customerIds), tenantWhere(req, dollarWalletTable.businessId)];
  if (!allTime) {
    periodConds.push(gte(dollarWalletTable.date, localDayString(start)));
    periodConds.push(lte(dollarWalletTable.date, localDayString(end)));
  }

  const periodRows = await db.select({
    partyId: dollarWalletTable.partyId,
    entryType: dollarWalletTable.entryType,
    usd: sql<string>`coalesce(sum(cast(${dollarWalletTable.amountUsd} as numeric)), 0)`,
    pkr: sql<string>`coalesce(sum(cast(${dollarWalletTable.totalPkr} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(dollarWalletTable).where(and(...periodConds)).groupBy(dollarWalletTable.partyId, dollarWalletTable.entryType);

  // Lifetime aggregation per customer
  const lifetimeRows = await db.select({
    partyId: dollarWalletTable.partyId,
    entryType: dollarWalletTable.entryType,
    usd: sql<string>`coalesce(sum(cast(${dollarWalletTable.amountUsd} as numeric)), 0)`,
    pkr: sql<string>`coalesce(sum(cast(${dollarWalletTable.totalPkr} as numeric)), 0)`,
    count: sql<string>`count(*)`,
  }).from(dollarWalletTable)
    .where(and(eq(dollarWalletTable.partyType, "customer"), inArray(dollarWalletTable.partyId, customerIds)))
    .groupBy(dollarWalletTable.partyId, dollarWalletTable.entryType);

  // Build maps: partyId -> { entryType -> { usd, pkr, count } }
  type AggRow = { usd: number; pkr: number; count: number };
  const buildMap = (rows: { partyId: number | null; entryType: string; usd: string; pkr: string; count: string }[]) => {
    const m = new Map<number, Map<string, AggRow>>();
    for (const r of rows) {
      if (!r.partyId) continue;
      if (!m.has(r.partyId)) m.set(r.partyId, new Map());
      m.get(r.partyId)!.set(r.entryType, { usd: parseFloat(r.usd), pkr: parseFloat(r.pkr), count: parseInt(r.count) });
    }
    return m;
  };

  const periodMap   = buildMap(periodRows);
  const lifetimeMap = buildMap(lifetimeRows);

  const agg = (byType: Map<string, AggRow>, types: string[]) =>
    types.reduce((s, t) => ({ usd: s.usd + (byType.get(t)?.usd ?? 0), pkr: s.pkr + (byType.get(t)?.pkr ?? 0), count: s.count + (byType.get(t)?.count ?? 0) }), { usd: 0, pkr: 0, count: 0 });

  const result = customers.map(c => {
    const pm = periodMap.get(c.id) ?? new Map<string, AggRow>();
    const lm = lifetimeMap.get(c.id) ?? new Map<string, AggRow>();

    const pIn  = agg(pm, USD_IN_TYPES);
    const pOut = agg(pm, USD_OUT_TYPES);
    const lIn  = agg(lm, USD_IN_TYPES);
    const lOut = agg(lm, USD_OUT_TYPES);

    return {
      customerId:   c.id,
      customerName: c.name,
      phone:        c.phone ?? null,
      period: {
        usdIn:    pIn.usd.toFixed(2),
        usdOut:   pOut.usd.toFixed(2),
        netUsd:   (pIn.usd - pOut.usd).toFixed(2),
        pkrTotal: (pIn.pkr + pOut.pkr).toFixed(2),
        entryCount: pIn.count + pOut.count,
      },
      lifetime: {
        usdIn:    lIn.usd.toFixed(2),
        usdOut:   lOut.usd.toFixed(2),
        netUsd:   (lIn.usd - lOut.usd).toFixed(2),
        pkrTotal: (lIn.pkr + lOut.pkr).toFixed(2),
        entryCount: lIn.count + lOut.count,
      },
    };
  }).sort((a, b) => parseFloat(b.lifetime.usdIn) - parseFloat(a.lifetime.usdIn));

  const totals = result.reduce((acc, r) => ({
    periodUsdIn:  acc.periodUsdIn  + parseFloat(r.period.usdIn),
    periodUsdOut: acc.periodUsdOut + parseFloat(r.period.usdOut),
    periodNet:    acc.periodNet    + parseFloat(r.period.netUsd),
    lifetimeUsdIn:  acc.lifetimeUsdIn  + parseFloat(r.lifetime.usdIn),
    lifetimeUsdOut: acc.lifetimeUsdOut + parseFloat(r.lifetime.usdOut),
    lifetimeNet:    acc.lifetimeNet    + parseFloat(r.lifetime.netUsd),
  }), { periodUsdIn: 0, periodUsdOut: 0, periodNet: 0, lifetimeUsdIn: 0, lifetimeUsdOut: 0, lifetimeNet: 0 });

  res.json({
    startDate: start.toISOString(),
    endDate:   end.toISOString(),
    allTime,
    customers: result,
    totals: {
      periodUsdIn:    totals.periodUsdIn.toFixed(2),
      periodUsdOut:   totals.periodUsdOut.toFixed(2),
      periodNet:      totals.periodNet.toFixed(2),
      lifetimeUsdIn:  totals.lifetimeUsdIn.toFixed(2),
      lifetimeUsdOut: totals.lifetimeUsdOut.toFixed(2),
      lifetimeNet:    totals.lifetimeNet.toFixed(2),
    },
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// CASH FLOW V2 — user-daily sales orders + transfers + company IN/OUT flow
// GET /api/reports/cash-flow-v2?startDate&endDate&userId
// ─────────────────────────────────────────────────────────────────────────────
router.get("/reports/cash-flow-v2", requireAuth, async (req, res): Promise<void> => {
  const scope = readScope(req as never);
  if ("error" in scope) { res.status(scope.error.status).json(scope.error.body); return; }
  const { start, end } = parseDateRange(req as never);
  const filterUserId = typeof req.query.userId === "string" && req.query.userId ? parseInt(req.query.userId) : null;

  // ── helpers ──────────────────────────────────────────────────────────────
  const dayOf = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  // ── users map ─────────────────────────────────────────────────────────────
  const allUsers = await db.select({ id: usersTable.id, name: usersTable.name }).from(usersTable).where(tenantWhere(req, usersTable.businessId));
  const userMap = new Map(allUsers.map(u => [u.id, u.name ?? `User #${u.id}`]));

  // ── SALES (orders) ───────────────────────────────────────────────────────
  const saleConds: ReturnType<typeof eq>[] = [gte(salesTable.createdAt, start), lte(salesTable.createdAt, end), tenantWhere(req, salesTable.businessId) as ReturnType<typeof eq>];
  if (scope.locationId) saleConds.push(eq(salesTable.locationId, scope.locationId) as ReturnType<typeof eq>);
  if (filterUserId)     saleConds.push(eq(salesTable.userId, filterUserId) as ReturnType<typeof eq>);

  const rawSales = await db.select({
    id: salesTable.id,
    userId: salesTable.userId,
    total: salesTable.total,
    amountPaid: salesTable.amountPaid,
    paymentMethod: salesTable.paymentMethod,
    status: salesTable.status,
    createdAt: salesTable.createdAt,
    customerName: customersTable.name,
    locationName: locationsTable.name,
  })
  .from(salesTable)
  .leftJoin(customersTable, eq(salesTable.customerId, customersTable.id))
  .leftJoin(locationsTable, eq(salesTable.locationId, locationsTable.id))
  .where(and(...saleConds))
  .orderBy(desc(salesTable.createdAt));

  // Group: date → userId → [sales]
  const ordersMap = new Map<string, Map<number, typeof rawSales>>();
  for (const sale of rawSales) {
    const day = dayOf(sale.createdAt);
    if (!ordersMap.has(day)) ordersMap.set(day, new Map());
    const dayMap = ordersMap.get(day)!;
    const uid = sale.userId ?? 0;
    if (!dayMap.has(uid)) dayMap.set(uid, []);
    dayMap.get(uid)!.push(sale);
  }

  const ordersByDay = Array.from(ordersMap.entries())
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([date, userMap2]) => {
      const byUser = Array.from(userMap2.entries()).map(([uid, sales]) => ({
        userId: uid,
        userName: userMap.get(uid) ?? `User #${uid}`,
        orders: sales.length,
        amount: sales.reduce((s, x) => s + parseFloat(x.amountPaid ?? "0"), 0),
        sales: sales.map(s => ({
          id: s.id,
          time: s.createdAt.toISOString(),
          customerName: s.customerName ?? "Walk-in",
          total: parseFloat(s.total ?? "0"),
          amountPaid: parseFloat(s.amountPaid ?? "0"),
          paymentMethod: s.paymentMethod ?? "cash",
          status: s.status ?? "completed",
          locationName: s.locationName ?? null,
        })),
      })).sort((a, b) => b.amount - a.amount);
      return {
        date,
        totalAmount: byUser.reduce((s, u) => s + u.amount, 0),
        totalOrders: byUser.reduce((s, u) => s + u.orders, 0),
        byUser,
      };
    });

  // ── TRANSFERS (audit log) ────────────────────────────────────────────────
  const transferConds = [
    sql`lower(${auditLogsTable.action}) = 'transfer'`,
    eq(auditLogsTable.entityType, "account"),
    gte(auditLogsTable.createdAt, start),
    lte(auditLogsTable.createdAt, end),
    tenantWhere(req, auditLogsTable.businessId),
  ];
  if (filterUserId) transferConds.push(eq(auditLogsTable.userId, filterUserId));

  const rawTransfers = await db.select().from(auditLogsTable)
    .where(and(...transferConds))
    .orderBy(desc(auditLogsTable.createdAt));

  // parse "Transfer {amount} from account #{fromId} to #{toId}: notes"
  const amtRe = /Transfer\s+([\d.]+)/i;
  const transfers = rawTransfers.map(t => {
    const amtMatch = amtRe.exec(t.details ?? "");
    const amount = amtMatch ? parseFloat(amtMatch[1]!) : 0;
    return {
      id: t.id,
      createdAt: t.createdAt.toISOString(),
      details: t.details ?? "",
      amount,
      userId: t.userId,
      userName: userMap.get(t.userId ?? -1) ?? `User #${t.userId}`,
      day: dayOf(t.createdAt),
    };
  });

  // ── PURCHASES cash out ────────────────────────────────────────────────────
  const pursConds: ReturnType<typeof eq>[] = [gte(purchasesTable.createdAt, start), lte(purchasesTable.createdAt, end), tenantWhere(req, purchasesTable.businessId) as ReturnType<typeof eq>];
  if (scope.locationId) pursConds.push(eq(purchasesTable.locationId, scope.locationId) as ReturnType<typeof eq>);
  const rawPurchases = await db.select({
    amountPaid: purchasesTable.amountPaid,
    createdAt: purchasesTable.createdAt,
  }).from(purchasesTable).where(and(...pursConds));

  // ── EXPENSES cash out ─────────────────────────────────────────────────────
  const startDay = localDayString(start);
  const endDay   = localDayString(end);
  const expConds: ReturnType<typeof eq>[] = [gte(expensesTable.date, startDay), lte(expensesTable.date, endDay), tenantWhere(req, expensesTable.businessId) as ReturnType<typeof eq>];
  const rawExpenses = await db.select({ amount: expensesTable.amount, date: expensesTable.date }).from(expensesTable).where(and(...expConds));

  // ── FLOW: daily IN vs OUT ─────────────────────────────────────────────────
  const flowMap = new Map<string, { salesIn: number; purchasesOut: number; expensesOut: number; transfersOut: number }>();
  const ensureDay = (d: string) => {
    if (!flowMap.has(d)) flowMap.set(d, { salesIn: 0, purchasesOut: 0, expensesOut: 0, transfersOut: 0 });
    return flowMap.get(d)!;
  };
  for (const s of rawSales)   ensureDay(dayOf(s.createdAt)).salesIn       += parseFloat(s.amountPaid ?? "0");
  for (const p of rawPurchases) ensureDay(dayOf(p.createdAt)).purchasesOut += parseFloat(p.amountPaid ?? "0");
  for (const e of rawExpenses)  ensureDay(e.date).expensesOut              += parseFloat(e.amount ?? "0");
  for (const t of transfers)    ensureDay(t.day).transfersOut              += t.amount;

  const flowByDay = Array.from(flowMap.entries())
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([date, f]) => ({
      date,
      salesIn:       f.salesIn,
      purchasesOut:  f.purchasesOut,
      expensesOut:   f.expensesOut,
      transfersOut:  f.transfersOut,
      totalIn:       f.salesIn,
      totalOut:      f.purchasesOut + f.expensesOut + f.transfersOut,
      net:           f.salesIn - (f.purchasesOut + f.expensesOut + f.transfersOut),
    }));

  const flowTotals = flowByDay.reduce((acc, d) => ({
    totalIn:  acc.totalIn  + d.totalIn,
    totalOut: acc.totalOut + d.totalOut,
    net:      acc.net      + d.net,
  }), { totalIn: 0, totalOut: 0, net: 0 });

  // ── all users (for filter dropdown) ───────────────────────────────────────
  const userList = allUsers.map(u => ({ id: u.id, name: u.name ?? `User #${u.id}` }));

  res.json({
    period: { start: start.toISOString(), end: end.toISOString() },
    users: userList,
    orders: ordersByDay,
    transfers,
    flow: { byDay: flowByDay, totals: flowTotals },
  });
});

export default router;
