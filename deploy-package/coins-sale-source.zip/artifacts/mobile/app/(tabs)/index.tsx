import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useState, useMemo } from "react";
import {
  Alert, FlatList, Image, Modal, Platform, ScrollView,
  StyleSheet, Text, TextInput, TouchableOpacity, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  useListProducts, useListCustomers, useListAccounts, useListLocations,
  useCreateSale, customFetch,
} from "@workspace/api-client-react";
import { useAuth, hasPrivilege, getAllowedProductIds, getAllowedAccountIds, getAllowedLocationIds } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const NUMPAD_KEYS = [["7", "8", "9"], ["4", "5", "6"], ["1", "2", "3"], [".", "0", "⌫"]];

function formatK(n: number): string {
  if (Math.abs(n) >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (Math.abs(n) >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

type MyTargetProgress = {
  targetId: number;
  title: string;
  type: string;
  startDate: string;
  endDate: string;
  targetAmount: string;
  achievedAmount: string;
  achievedPct: string;
  commissionType: string;
  commissionValue: string;
  maxBonus: string;
  earnedBonus: string;
  leftBonus: string;
};

type Product = { id: number; name: string; unitPrice: string; wholesalePrice: string; unit: string; stock: number; isActive?: boolean; imageUrl?: string | null; categoryName?: string | null; locationId?: number | null };
type Customer = { id: number; name: string; phone?: string | null; creditBalance?: string | null; locationId?: number | null };
type Account = { id: number; name: string; type: string; balance: string; currency: string; locationId?: number | null };
type Location = { id: number; name: string; address?: string | null };
type RateMode = "normal" | "wholesale";
type ValidationRule = { id: string; label: string; pass: boolean; severity: "error" | "warning" };

// ── Account type helpers ────────────────────────────────────────────────
function normalizeAcctType(raw: string): string {
  const t = raw.toLowerCase().replace(/[\s_-]/g, "");
  if (t.includes("jazzcash") || t === "jazz") return "jazzcash";
  if (t.includes("easypaisa") || t === "easy") return "easypaisa";
  if (t === "cash") return "cash";
  if (t === "bank") return "bank";
  if (t === "mobile" || t === "wallet") return "mobile";
  return "other";
}
function acctEmoji(type: string): string {
  const t = normalizeAcctType(type);
  if (t === "jazzcash")  return "🟠";
  if (t === "easypaisa") return "🟢";
  if (t === "cash")      return "💵";
  if (t === "bank")      return "🏦";
  if (t === "mobile")    return "📱";
  return "💳";
}
function acctColor(type: string): { bg: string; border: string; text: string } {
  const t = normalizeAcctType(type);
  if (t === "jazzcash")  return { bg: "#FFF7ED", border: "#F97316", text: "#7C2D12" };
  if (t === "easypaisa") return { bg: "#F0FDF4", border: "#22C55E", text: "#14532D" };
  if (t === "cash")      return { bg: "#ECFDF5", border: "#059669", text: "#065F46" };
  if (t === "bank")      return { bg: "#EFF6FF", border: "#2563EB", text: "#1E3A8A" };
  if (t === "mobile")    return { bg: "#F3E8FF", border: "#7C3AED", text: "#4C1D95" };
  return { bg: "#F1F5F9", border: "#94A3B8", text: "#334155" };
}

function AccountPickerModal({ visible, accounts, onSelect, onClose }: {
  visible: boolean;
  accounts: Account[];
  onSelect: (a: Account | null) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const ORDER = ["jazzcash", "easypaisa", "cash", "bank", "mobile", "other"];
  const TYPE_LABEL: Record<string, string> = {
    jazzcash: "Jazz Cash",
    easypaisa: "Easypaisa",
    cash: "Cash",
    bank: "Bank",
    mobile: "Mobile Wallet",
    other: "Other",
  };

  const grouped: Record<string, Account[]> = {};
  for (const a of accounts) {
    const key = normalizeAcctType(a.type);
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(a);
  }
  const sections = ORDER.filter(k => grouped[k]?.length);

  const [activeTab, setActiveTab] = useState<string>(sections[0] ?? "");

  // Reset tab when visible/accounts change
  React.useEffect(() => {
    if (visible && sections.length > 0) setActiveTab(sections[0]!);
  }, [visible, accounts.length]);

  const activeAccts = grouped[activeTab] ?? [];
  const { bg: tabBg, border: tabBorder, text: tabText } = acctColor(activeTab);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: "80%" }}>

          {/* Header */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, paddingTop: 18, paddingBottom: 12 }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.text }}>Select Account</Text>
            <TouchableOpacity style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: colors.input, alignItems: "center", justifyContent: "center" }} onPress={onClose}>
              <Text style={{ color: colors.mutedForeground, fontSize: 20, lineHeight: 22 }}>×</Text>
            </TouchableOpacity>
          </View>

          {/* Type tab bar — single horizontal line */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ flexDirection: "row", gap: 8, paddingHorizontal: 14, paddingBottom: 12 }}
          >
            {sections.map(typeKey => {
              const { bg, border, text } = acctColor(typeKey);
              const isActive = typeKey === activeTab;
              return (
                <TouchableOpacity
                  key={typeKey}
                  onPress={() => setActiveTab(typeKey)}
                  activeOpacity={0.75}
                  style={{
                    flexDirection: "row", alignItems: "center", gap: 5,
                    paddingHorizontal: 12, paddingVertical: 8,
                    borderRadius: 20, borderWidth: isActive ? 2 : 1.5,
                    backgroundColor: isActive ? bg : colors.card,
                    borderColor: isActive ? border : colors.border,
                  }}
                >
                  <Text style={{ fontSize: 14 }}>{acctEmoji(typeKey)}</Text>
                  <Text style={{ fontFamily: isActive ? "Inter_700Bold" : "Inter_500Medium", fontSize: 12, color: isActive ? text : colors.mutedForeground }}>
                    {TYPE_LABEL[typeKey]}
                  </Text>
                  <View style={{ backgroundColor: isActive ? border : colors.border, borderRadius: 10, paddingHorizontal: 5, paddingVertical: 1 }}>
                    <Text style={{ fontFamily: "Inter_700Bold", fontSize: 9, color: isActive ? "#fff" : colors.mutedForeground }}>
                      {grouped[typeKey]?.length ?? 0}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* Divider */}
          <View style={{ height: 1, backgroundColor: colors.border, marginHorizontal: 14, marginBottom: 12 }} />

          {/* Accounts grid for selected type */}
          <ScrollView contentContainerStyle={{ flexDirection: "row", flexWrap: "wrap", gap: 10, paddingHorizontal: 14, paddingBottom: 28 }}>
            {activeAccts.map(a => (
              <TouchableOpacity
                key={a.id}
                style={{
                  width: "30%",
                  backgroundColor: tabBg,
                  borderRadius: 16,
                  borderWidth: 2,
                  borderColor: tabBorder,
                  alignItems: "center",
                  paddingVertical: 14,
                  paddingHorizontal: 6,
                  gap: 7,
                }}
                onPress={() => { onSelect(a); onClose(); }}
                activeOpacity={0.75}
              >
                <View style={{ width: 50, height: 50, borderRadius: 15, backgroundColor: "#fff", borderWidth: 2, borderColor: tabBorder, alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 26 }}>{acctEmoji(activeTab)}</Text>
                </View>
                <Text style={{ fontFamily: "Inter_700Bold", fontSize: 12, color: tabText, textAlign: "center" }} numberOfLines={1}>
                  {a.name}
                </Text>
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: tabText, textAlign: "center" }} numberOfLines={1}>
                  ₨{parseFloat(a.balance).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

        </View>
      </View>
    </Modal>
  );
}

function CustomerPickerModal({ visible, customers, locations, onSelect, onClose }: {
  visible: boolean;
  customers: Customer[];
  locations: Location[];
  onSelect: (c: Customer | null) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<number | "all">("all");
  const [search, setSearch] = useState("");

  React.useEffect(() => {
    if (visible) { setActiveTab("all"); setSearch(""); }
  }, [visible]);

  const tabs: { key: number | "all"; label: string }[] = [
    { key: "all", label: "All" },
    ...locations.map(l => ({ key: l.id, label: l.name })),
  ];

  const filtered = useMemo(() => {
    const byTab = activeTab === "all"
      ? customers
      : customers.filter(c => c.locationId === activeTab);
    const q = search.trim().toLowerCase();
    return q ? byTab.filter(c => c.name.toLowerCase().includes(q) || (c.phone ?? "").includes(q)) : byTab;
  }, [customers, activeTab, search]);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: "82%" }}>

          {/* Header */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, paddingTop: 18, paddingBottom: 10 }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.text }}>Select Customer</Text>
            <TouchableOpacity style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: colors.input, alignItems: "center", justifyContent: "center" }} onPress={onClose}>
              <Text style={{ color: colors.mutedForeground, fontSize: 20, lineHeight: 22 }}>×</Text>
            </TouchableOpacity>
          </View>

          {/* Location (App) tab bar */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ flexDirection: "row", gap: 7, paddingHorizontal: 14, paddingBottom: 10 }}
          >
            {tabs.map(tab => {
              const isActive = tab.key === activeTab;
              const count = tab.key === "all"
                ? customers.length
                : customers.filter(c => c.locationId === tab.key).length;
              return (
                <TouchableOpacity
                  key={String(tab.key)}
                  onPress={() => setActiveTab(tab.key)}
                  activeOpacity={0.75}
                  style={{
                    flexDirection: "row", alignItems: "center", gap: 5,
                    paddingHorizontal: 12, paddingVertical: 7,
                    borderRadius: 20, borderWidth: isActive ? 2 : 1.5,
                    backgroundColor: isActive ? "#EFF6FF" : colors.card,
                    borderColor: isActive ? "#3B82F6" : colors.border,
                  }}
                >
                  <Text style={{ fontSize: 12 }}>{tab.key === "all" ? "🏪" : "📍"}</Text>
                  <Text style={{ fontFamily: isActive ? "Inter_700Bold" : "Inter_500Medium", fontSize: 12, color: isActive ? "#1E40AF" : colors.mutedForeground }}>
                    {tab.label}
                  </Text>
                  <View style={{ backgroundColor: isActive ? "#3B82F6" : colors.border, borderRadius: 10, paddingHorizontal: 5, paddingVertical: 1 }}>
                    <Text style={{ fontFamily: "Inter_700Bold", fontSize: 9, color: "#fff" }}>{count}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* Search */}
          <View style={{ marginHorizontal: 14, marginBottom: 8, flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.input, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 }}>
            <Text style={{ fontSize: 14 }}>🔍</Text>
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Search name or phone…"
              placeholderTextColor={colors.mutedForeground}
              style={{ flex: 1, fontFamily: "Inter_400Regular", fontSize: 13, color: colors.text }}
            />
          </View>

          {/* Divider */}
          <View style={{ height: 1, backgroundColor: colors.border, marginHorizontal: 14, marginBottom: 4 }} />

          {/* Walk-in row */}
          <TouchableOpacity
            onPress={() => { onSelect(null); onClose(); }}
            style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border }}
          >
            <View style={{ width: 38, height: 38, borderRadius: 11, backgroundColor: colors.secondary, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 18 }}>👥</Text>
            </View>
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 14, color: colors.mutedForeground }}>Walk-in (no customer)</Text>
          </TouchableOpacity>

          {/* Customer list */}
          <FlatList
            data={filtered}
            keyExtractor={c => String(c.id)}
            renderItem={({ item: c }) => (
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: colors.border }}
                onPress={() => { onSelect(c); onClose(); }}
                activeOpacity={0.75}
              >
                <View style={{ width: 38, height: 38, borderRadius: 11, backgroundColor: "#EFF6FF", borderWidth: 1.5, borderColor: "#93C5FD", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 18 }}>👤</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.text }}>{c.name}</Text>
                  {c.phone ? <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginTop: 1 }}>{c.phone}</Text> : null}
                </View>
                <Text style={{ fontSize: 16, color: colors.mutedForeground }}>›</Text>
              </TouchableOpacity>
            )}
            ListEmptyComponent={
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 13, color: colors.mutedForeground, textAlign: "center", paddingVertical: 24 }}>No customers found</Text>
            }
          />
        </View>
      </View>
    </Modal>
  );
}

const LOCATION_PALETTES = [
  { bg: "#EFF6FF", border: "#3B82F6", text: "#1E40AF", emoji: "🏪" },
  { bg: "#ECFDF5", border: "#10B981", text: "#065F46", emoji: "🏬" },
  { bg: "#FFF7ED", border: "#F97316", text: "#9A3412", emoji: "🛒" },
  { bg: "#F3E8FF", border: "#8B5CF6", text: "#4C1D95", emoji: "🏷️" },
  { bg: "#FEF2F2", border: "#EF4444", text: "#7F1D1D", emoji: "🏢" },
  { bg: "#F0FDF4", border: "#22C55E", text: "#14532D", emoji: "🏦" },
  { bg: "#FDF4FF", border: "#D946EF", text: "#701A75", emoji: "🏩" },
  { bg: "#FFFBEB", border: "#F59E0B", text: "#78350F", emoji: "⭐" },
];

function LocationPickerModal({ visible, locations, onSelect, onClose }: {
  visible: boolean;
  locations: Location[];
  onSelect: (l: Location) => void;
  onClose: () => void;
}) {
  const colors = useColors();

  if (!visible) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>

          {/* Header */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18, paddingTop: 18, paddingBottom: 14 }}>
            <View>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.text }}>Select App</Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground, marginTop: 2 }}>
                {locations.length} location{locations.length !== 1 ? "s" : ""} available
              </Text>
            </View>
            <TouchableOpacity style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: colors.input, alignItems: "center", justifyContent: "center" }} onPress={onClose}>
              <Text style={{ color: colors.mutedForeground, fontSize: 20, lineHeight: 22 }}>×</Text>
            </TouchableOpacity>
          </View>

          {/* Horizontal brand cards */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ flexDirection: "row", gap: 12, paddingHorizontal: 16, paddingBottom: 32 }}
          >
            {locations.map((loc, idx) => {
              const p = LOCATION_PALETTES[idx % LOCATION_PALETTES.length]!;
              return (
                <TouchableOpacity
                  key={loc.id}
                  onPress={() => { onSelect(loc); onClose(); }}
                  activeOpacity={0.75}
                  style={{
                    width: 130,
                    backgroundColor: p.bg,
                    borderRadius: 20,
                    borderWidth: 2,
                    borderColor: p.border,
                    alignItems: "center",
                    paddingVertical: 20,
                    paddingHorizontal: 10,
                    gap: 10,
                  }}
                >
                  {/* Brand icon */}
                  <View style={{ width: 60, height: 60, borderRadius: 18, backgroundColor: "#fff", borderWidth: 2, borderColor: p.border, alignItems: "center", justifyContent: "center" }}>
                    <Text style={{ fontSize: 30 }}>{p.emoji}</Text>
                  </View>
                  {/* Location name */}
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: p.text, textAlign: "center" }} numberOfLines={2}>
                    {loc.name}
                  </Text>
                  {/* Address */}
                  {loc.address ? (
                    <Text style={{ fontFamily: "Inter_400Regular", fontSize: 10, color: p.text, textAlign: "center", opacity: 0.7 }} numberOfLines={2}>
                      📍 {loc.address}
                    </Text>
                  ) : null}
                  {/* Select label */}
                  <View style={{ backgroundColor: p.border, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 5 }}>
                    <Text style={{ fontFamily: "Inter_700Bold", fontSize: 10, color: "#fff" }}>SELECT</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

        </View>
      </View>
    </Modal>
  );
}

function PickerModal<T extends { id: number; name: string }>({
  visible, title, items, onSelect, onClose, renderSub,
}: { visible: boolean; title: string; items: T[]; onSelect: (item: T | null) => void; onClose: () => void; renderSub?: (item: T) => string }) {
  const colors = useColors();
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: "80%" }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: colors.text }}>{title}</Text>
            <TouchableOpacity style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.input, alignItems: "center", justifyContent: "center" }} onPress={onClose}>
              <Text style={{ color: colors.mutedForeground, fontSize: 22, fontFamily: "Inter_500Medium", lineHeight: 24 }}>×</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity onPress={() => { onSelect(null); onClose(); }} style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <Text style={{ fontFamily: "Inter_500Medium", color: colors.mutedForeground, fontSize: 15 }}>— None —</Text>
          </TouchableOpacity>
          <FlatList
            data={items}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => (
              <TouchableOpacity style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: colors.border }} onPress={() => { onSelect(item); onClose(); }}>
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 15, color: colors.text }}>{item.name}</Text>
                {renderSub && <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 }}>{renderSub(item)}</Text>}
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    </Modal>
  );
}

function ProductPickerModal({ visible, products, allProducts, locations, onSelect, onClose }: {
  visible: boolean;
  products: Product[];
  allProducts: Product[];
  locations: Location[];
  onSelect: (p: Product) => void;
  onClose: () => void;
}) {
  const colors = useColors();
  const [search, setSearch] = useState("");
  const [showAllApps, setShowAllApps] = useState(false);

  const source = showAllApps ? allProducts : products;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? source.filter(p => p.name.toLowerCase().includes(q) || (p.categoryName ?? "").toLowerCase().includes(q)) : source;
  }, [source, search]);

  // When showing all apps, group by location → category; otherwise by category only
  type GroupEntry = { key: string; label: string; sublabel?: string; items: Product[]; isLocationHeader?: boolean };

  const groups = useMemo((): GroupEntry[] => {
    if (!showAllApps) {
      const map = new Map<string, Product[]>();
      for (const p of filtered) {
        const cat = p.categoryName?.trim() || "Uncategorized";
        const arr = map.get(cat) ?? [];
        arr.push(p);
        map.set(cat, arr);
      }
      return Array.from(map.entries())
        .sort(([a], [b]) => a === "Uncategorized" ? 1 : b === "Uncategorized" ? -1 : a.localeCompare(b))
        .map(([cat, items]) => ({ key: cat, label: cat, items }));
    }

    // Group by location, then by category within each location
    const locMap = new Map<number | null, Product[]>();
    for (const p of filtered) {
      const lid = p.locationId ?? null;
      const arr = locMap.get(lid) ?? [];
      arr.push(p);
      locMap.set(lid, arr);
    }

    const result: GroupEntry[] = [];
    const locOrder = [...locMap.keys()].sort((a, b) => {
      if (a === null) return 1;
      if (b === null) return -1;
      const la = locations.find(l => l.id === a)?.name ?? "";
      const lb = locations.find(l => l.id === b)?.name ?? "";
      return la.localeCompare(lb);
    });

    for (const lid of locOrder) {
      const locName = lid !== null ? (locations.find(l => l.id === lid)?.name ?? `App #${lid}`) : "No App";
      const locProducts = locMap.get(lid) ?? [];
      const totalStock = locProducts.reduce((s, p) => s + (p.stock ?? 0), 0);

      // Group by category within location
      const catMap = new Map<string, Product[]>();
      for (const p of locProducts) {
        const cat = p.categoryName?.trim() || "Uncategorized";
        const arr = catMap.get(cat) ?? [];
        arr.push(p);
        catMap.set(cat, arr);
      }
      const cats = Array.from(catMap.entries())
        .sort(([a], [b]) => a === "Uncategorized" ? 1 : b === "Uncategorized" ? -1 : a.localeCompare(b));

      for (const [cat, items] of cats) {
        result.push({
          key: `${lid ?? "null"}-${cat}`,
          label: cat,
          sublabel: `${locName}  ·  Total stock: ${totalStock} units`,
          items,
          isLocationHeader: cats.indexOf(cats.find(c => c[0] === cat)!) === 0,
        });
      }
    }
    return result;
  }, [filtered, showAllApps, locations]);

  const CARD_W = 104;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: "90%" }}>
          {/* Header */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12 }}>
            <View>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 19, color: colors.text }}>Select Product</Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: colors.mutedForeground, marginTop: 2 }}>
                {filtered.length} items · {showAllApps ? `${locations.length} apps` : "current app"}
              </Text>
            </View>
            <TouchableOpacity style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.input, alignItems: "center", justifyContent: "center" }} onPress={onClose}>
              <Text style={{ color: colors.mutedForeground, fontSize: 22, fontFamily: "Inter_500Medium", lineHeight: 24 }}>×</Text>
            </TouchableOpacity>
          </View>

          {/* All Apps toggle */}
          <View style={{ flexDirection: "row", marginHorizontal: 16, marginBottom: 8, gap: 8 }}>
            <TouchableOpacity
              onPress={() => setShowAllApps(false)}
              style={{
                flex: 1, paddingVertical: 8, borderRadius: 12, alignItems: "center", borderWidth: 1.5,
                borderColor: !showAllApps ? colors.primary : colors.border,
                backgroundColor: !showAllApps ? colors.primary : colors.input,
              }}
            >
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 12, color: !showAllApps ? "#FFF" : colors.mutedForeground }}>
                📍 Current App
              </Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 10, color: !showAllApps ? "rgba(255,255,255,0.7)" : colors.mutedForeground }}>
                {products.length} products
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setShowAllApps(true)}
              style={{
                flex: 1, paddingVertical: 8, borderRadius: 12, alignItems: "center", borderWidth: 1.5,
                borderColor: showAllApps ? colors.primary : colors.border,
                backgroundColor: showAllApps ? colors.primary : colors.input,
              }}
            >
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 12, color: showAllApps ? "#FFF" : colors.mutedForeground }}>
                🌐 All Apps
              </Text>
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 10, color: showAllApps ? "rgba(255,255,255,0.7)" : colors.mutedForeground }}>
                {allProducts.length} products · {locations.length} apps
              </Text>
            </TouchableOpacity>
          </View>

          {/* Search bar */}
          <View style={{ marginHorizontal: 16, marginBottom: 10, flexDirection: "row", alignItems: "center", backgroundColor: colors.input, borderRadius: 14, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border }}>
            <Text style={{ fontSize: 16, marginRight: 8 }}>🔍</Text>
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder="Search products or categories…"
              placeholderTextColor={colors.mutedForeground}
              style={{ flex: 1, fontFamily: "Inter_400Regular", fontSize: 14, color: colors.text, paddingVertical: 10 }}
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")} style={{ padding: 4 }}>
                <Text style={{ fontSize: 15, color: colors.mutedForeground }}>✕</Text>
              </TouchableOpacity>
            )}
          </View>

          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
            {groups.length === 0 ? (
              <View style={{ alignItems: "center", paddingTop: 40 }}>
                <Text style={{ fontSize: 36 }}>🔍</Text>
                <Text style={{ fontFamily: "Inter_500Medium", color: colors.mutedForeground, marginTop: 8 }}>No products found</Text>
              </View>
            ) : groups.map((group) => (
              <View key={group.key} style={{ marginBottom: 6 }}>
                {/* Category / App header */}
                <View style={{ paddingHorizontal: 16, paddingTop: group.sublabel ? 10 : 4, paddingBottom: 6 }}>
                  {group.sublabel && (
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 3 }}>
                      <Text style={{ fontSize: 12 }}>📍</Text>
                      <Text style={{ fontFamily: "Inter_700Bold", fontSize: 11, color: colors.primary }}>{group.sublabel.split(" · ")[0]}</Text>
                      <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 10, color: colors.mutedForeground }}>{group.sublabel.split(" · ")[1]}</Text>
                    </View>
                  )}
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                    <View style={{ height: 1, width: 8, backgroundColor: colors.border }} />
                    <Text style={{ fontFamily: "Inter_700Bold", fontSize: 11, color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 1 }}>{group.label}</Text>
                    <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                    <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: colors.mutedForeground }}>{group.items.length}</Text>
                  </View>
                </View>

                {/* Product grid */}
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 12, gap: 10, flexDirection: "row" }}>
                  {group.items.map(p => {
                    const inStock = (p.stock ?? 0) > 0;
                    const price = parseFloat(p.unitPrice);
                    return (
                      <TouchableOpacity
                        key={p.id}
                        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {}); onSelect(p); onClose(); }}
                        activeOpacity={0.75}
                        style={{
                          width: CARD_W, borderRadius: 18, borderWidth: 2,
                          borderColor: inStock ? colors.border : colors.danger,
                          backgroundColor: inStock ? colors.card : colors.dangerBg,
                          padding: 10, alignItems: "center", gap: 6,
                          shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 6, shadowOffset: { width: 0, height: 2 },
                          elevation: 2,
                        }}
                      >
                        {p.imageUrl ? (
                          <Image source={{ uri: p.imageUrl }} style={{ width: 56, height: 56, borderRadius: 14 }} />
                        ) : (
                          <View style={{ width: 56, height: 56, borderRadius: 14, backgroundColor: inStock ? colors.secondary : colors.dangerBg, alignItems: "center", justifyContent: "center" }}>
                            <Text style={{ fontSize: 28 }}>{inStock ? "📦" : "🚫"}</Text>
                          </View>
                        )}

                        {!inStock && (
                          <View style={{ backgroundColor: colors.danger, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 9, color: "#FFF" }}>OUT OF STOCK</Text>
                          </View>
                        )}

                        <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: colors.text, textAlign: "center" }} numberOfLines={2}>{p.name}</Text>

                        <View style={{ alignItems: "center", gap: 2 }}>
                          <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.primary }}>
                            ₨{price >= 1000 ? `${(price / 1000).toFixed(1)}K` : price.toFixed(0)}
                          </Text>
                          <Text style={{ fontFamily: "Inter_400Regular", fontSize: 10, color: inStock ? colors.success : colors.danger }}>
                            {inStock ? `${p.stock} ${p.unit}` : "0 in stock"}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

export default function POSScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const topPad = Platform.OS === "web" ? 20 : insets.top;

  // ── Privileges ─────────────────────────────────────────────────────────
  const isAdmin           = user?.role === "admin";
  const canSelectProduct  = hasPrivilege(user, "pos_product");
  const canSelectAccount  = hasPrivilege(user, "pos_account");
  const canCreditSale     = hasPrivilege(user, "pos_credit_customer");
  const canSelectLocation = hasPrivilege(user, "pos_location");

  const [amount, setAmount] = useState("0");
  const [rateMode, setRateMode] = useState<RateMode>("normal");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [copiedQty, setCopiedQty] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [dollarBalance, setDollarBalance] = useState<{ usd: number; pkr: number; rate: number } | null>(null);
  const [defaults, setDefaults] = useState<{ locationId?: number; accountId?: number; productId?: number }>({});
  const [strictMode, setStrictMode] = useState(true);

  const { data: productsRaw } = useListProducts();
  const { data: customersRaw } = useListCustomers();
  const { data: accountsRaw } = useListAccounts();
  const { data: locationsRaw } = useListLocations();
  const createSaleMutation = useCreateSale();

  // ── My Target Progress (each user sees only their own assigned target) ──
  const { data: myTargetProgress } = useQuery<MyTargetProgress | null>({
    queryKey: ["my-target-progress", user?.id],
    queryFn: () => customFetch<MyTargetProgress | null>("/api/targets/my-progress"),
    refetchInterval: 30_000,
    enabled: !!user?.id,
  });

  React.useEffect(() => {
    customFetch<{ entryType: string; amountUsd: string; rate: string }[]>("/api/dollar-wallet")
      .then(rows => {
        const SIGNS: Record<string, number> = { received: 1, partial: 1, recovery: 1, product: -1 };
        let usd = 0; let lastRate = 0;
        rows.forEach(r => {
          usd += (SIGNS[r.entryType] ?? 1) * parseFloat(r.amountUsd);
          if (!lastRate) lastRate = parseFloat(r.rate);
        });
        setDollarBalance({ usd, pkr: usd * lastRate, rate: lastRate });
      }).catch(() => {});
  }, []);

  // ── Load persisted defaults + strict mode ─────────────────────────────
  React.useEffect(() => {
    AsyncStorage.getItem("pos_defaults").then(raw => {
      if (raw) {
        try { setDefaults(JSON.parse(raw)); } catch {}
      }
    }).catch(() => {});
    AsyncStorage.getItem("pos_strict_mode").then(v => {
      if (v !== null) setStrictMode(v !== "false");
    }).catch(() => {});
  }, []);

  // ── Auto-apply defaults once data has loaded ───────────────────────────
  const defaultsAppliedRef = React.useRef(false);
  React.useEffect(() => {
    if (defaultsAppliedRef.current) return;
    const p = (productsRaw ?? []) as unknown as Product[];
    const a = (accountsRaw ?? []) as unknown as Account[];
    const l = (locationsRaw ?? []) as unknown as Location[];
    if (!p.length && !a.length && !l.length) return;
    defaultsAppliedRef.current = true;
    if (defaults.productId) {
      const found = p.find(x => x.id === defaults.productId && x.isActive !== false);
      if (found) setSelectedProduct(found);
    }
    if (defaults.accountId) {
      const found = a.find(x => x.id === defaults.accountId);
      if (found) setSelectedAccount(found);
    }
    if (defaults.locationId) {
      const found = l.find(x => x.id === defaults.locationId);
      if (found) setSelectedLocation(found);
    }
  }, [defaults, productsRaw, accountsRaw, locationsRaw]);

  const saveDefault = async (key: "locationId" | "accountId" | "productId", id: number) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    const next = { ...defaults, [key]: id };
    setDefaults(next);
    try { await AsyncStorage.setItem("pos_defaults", JSON.stringify(next)); } catch {}
  };

  const toggleStrictMode = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    const next = !strictMode;
    setStrictMode(next);
    AsyncStorage.setItem("pos_strict_mode", String(next)).catch(() => {});
  };

  const products = (productsRaw ?? []) as unknown as Product[];
  const customers = (customersRaw ?? []) as unknown as Customer[];
  const accounts = (accountsRaw ?? []) as unknown as Account[];
  const locations = (locationsRaw ?? []) as unknown as Location[];

  // ── Entity-level filtering ─────────────────────────────────────────────
  const allowedProductIds  = getAllowedProductIds(user);
  const allowedAccountIds  = getAllowedAccountIds(user);
  const allowedLocationIds = getAllowedLocationIds(user);

  const allActiveProducts = products
    .filter(p => p.isActive !== false)
    .filter(p => allowedProductIds === null || allowedProductIds.has(p.id));

  const activeProducts = allActiveProducts
    .filter(p => !selectedLocation || p.locationId === selectedLocation.id);

  const allowedAccounts = accounts
    .filter(a => allowedAccountIds === null || allowedAccountIds.has(a.id))
    .filter(a => !selectedLocation || a.locationId === selectedLocation.id);

  const activeCustomers = customers
    .filter(c => !selectedLocation || c.locationId === selectedLocation.id);

  const allowedLocations = locations
    .filter(l => allowedLocationIds === null || allowedLocationIds.has(l.id));

  // Auto-select if only one option allowed
  React.useEffect(() => {
    if (allowedAccounts.length === 1 && !selectedAccount) {
      setSelectedAccount(allowedAccounts[0]!);
    }
  }, [allowedAccounts.length]);

  React.useEffect(() => {
    if (activeProducts.length === 1 && !selectedProduct) {
      setSelectedProduct(activeProducts[0]!);
    }
  }, [activeProducts.length]);

  // Lock non-admin to their assigned location immediately when locations load
  React.useEffect(() => {
    if (!isAdmin && user?.locationId) {
      const assigned = locations.find(l => l.id === user.locationId);
      if (assigned) setSelectedLocation(assigned);
    } else if (isAdmin && allowedLocations.length === 1 && !selectedLocation) {
      setSelectedLocation(allowedLocations[0]!);
    }
  }, [locations.length, user?.locationId, isAdmin]);

  // Clear product/account/customer when location changes and they don't belong there
  React.useEffect(() => {
    if (!selectedLocation) return;
    if (selectedProduct && selectedProduct.locationId !== selectedLocation.id) {
      setSelectedProduct(null);
    }
    if (selectedAccount && selectedAccount.locationId !== selectedLocation.id) {
      setSelectedAccount(null);
    }
    if (selectedCustomer && selectedCustomer.locationId !== selectedLocation.id) {
      setSelectedCustomer(null);
    }
  }, [selectedLocation?.id]);

  const parsedAmount = parseFloat(amount) || 0;
  const activePrice = selectedProduct
    ? parseFloat(rateMode === "wholesale" ? (selectedProduct.wholesalePrice || selectedProduct.unitPrice) : selectedProduct.unitPrice)
    : 0;
  const qty = selectedProduct && parsedAmount > 0 && activePrice > 0 ? Math.round(parsedAmount / activePrice) : 0;

  // ── Rule-based strict validation ───────────────────────────────────────
  const stock = selectedProduct?.stock ?? 0;

  const allRules = useMemo((): ValidationRule[] => [
    {
      id: "product",
      label: "Product selected",
      pass: !!selectedProduct,
      severity: "error",
    },
    {
      id: "stock_nonzero",
      label: selectedProduct ? `In stock (${stock} ${selectedProduct.unit} avail.)` : "Product in stock",
      pass: !selectedProduct || stock > 0,
      severity: "error",
    },
    {
      id: "qty_lte_stock",
      label: `Qty ≤ stock (need ${qty}, have ${stock})`,
      pass: !selectedProduct || qty <= stock,
      severity: "error",
    },
    {
      id: "amount_positive",
      label: "Amount entered (> 0)",
      pass: parsedAmount > 0,
      severity: "error",
    },
    {
      id: "qty_min",
      label: "Qty ≥ 1 unit (amount large enough)",
      pass: qty >= 1 || parsedAmount === 0 || !selectedProduct,
      severity: "warning",
    },
  ], [selectedProduct, stock, qty, parsedAmount]);

  const cashRules = useMemo((): ValidationRule[] => [
    ...allRules,
    {
      id: "account",
      label: "Payment account selected",
      pass: !!selectedAccount,
      severity: "error",
    },
  ], [allRules, selectedAccount]);

  const creditRules = useMemo((): ValidationRule[] => [
    ...allRules,
    {
      id: "customer",
      label: "Customer selected for credit sale",
      pass: !!selectedCustomer,
      severity: "error",
    },
  ], [allRules, selectedCustomer]);

  const validations = useMemo(() => {
    const errors = allRules.filter(r => !r.pass && r.severity === "error").map(r => r.label);
    const warnings = allRules.filter(r => !r.pass && r.severity === "warning").map(r => r.label);
    return { errors, warnings, canSell: errors.length === 0 };
  }, [allRules]);

  const cashValidations = useMemo(() => {
    const errors = cashRules.filter(r => !r.pass && r.severity === "error").map(r => r.label);
    return { errors, canComplete: errors.length === 0 };
  }, [cashRules]);

  const creditValidations = useMemo(() => {
    const errors = creditRules.filter(r => !r.pass && r.severity === "error").map(r => r.label);
    return { errors, canComplete: errors.length === 0 };
  }, [creditRules]);

  // ── Dashboard figures (location/user-filtered for non-admin) ───────────
  const dashParams = isAdmin
    ? ""
    : `?userId=${user?.id ?? ""}${selectedLocation ? `&locationId=${selectedLocation.id}` : ""}`;

  type DashData = {
    totalAccountsBalance?: string; totalStockValue?: string;
    creditReceivable?: string; creditPayable?: string;
    todaySales?: string; todaySalesCount?: number;
    todayPurchases?: string; todayExpenses?: string;
  };

  const { data: dashboardRaw } = useQuery<DashData>({
    queryKey: ["dashboard-pos", dashParams],
    queryFn: () => customFetch<DashData>(`/api/dashboard${dashParams}`),
    refetchInterval: 30000,
  });

  const sep = dashParams.includes("?") ? "&" : "?";
  const todayParams  = `${dashParams}${sep}period=today`;
  const yestParams   = `${dashParams}${sep}period=yesterday`;

  const { data: todayDash } = useQuery<DashData>({
    queryKey: ["dashboard-today", todayParams],
    queryFn: () => customFetch<DashData>(`/api/dashboard${todayParams}`),
    refetchInterval: 30000,
  });
  const { data: yestDash } = useQuery<DashData>({
    queryKey: ["dashboard-yesterday", yestParams],
    queryFn: () => customFetch<DashData>(`/api/dashboard${yestParams}`),
    refetchInterval: 60000,
  });

  const todaySales = todayDash?.todaySales ? parseFloat(todayDash.todaySales) : null;
  const todayCount = todayDash?.todaySalesCount ?? null;
  const yestSales  = yestDash?.todaySales  ? parseFloat(yestDash.todaySales)  : null;
  const yestCount  = yestDash?.todaySalesCount ?? null;
  const salesDiff  = todaySales !== null && yestSales !== null ? todaySales - yestSales : null;
  const salesDiffPct = yestSales && yestSales > 0 && salesDiff !== null
    ? ((salesDiff / yestSales) * 100) : null;

  // BANK: admin → global accounts sum, non-admin → allowed accounts sum
  const bankBal = isAdmin
    ? (dashboardRaw?.totalAccountsBalance ? parseFloat(dashboardRaw.totalAccountsBalance) : null)
    : allowedAccounts.length > 0
      ? allowedAccounts.reduce((s, a) => s + parseFloat((a as { balance?: string }).balance ?? "0"), 0)
      : null;

  // STOCK: admin → global stock value, non-admin → selected location products
  const stockVal = isAdmin
    ? (dashboardRaw?.totalStockValue ? parseFloat(dashboardRaw.totalStockValue) : null)
    : selectedLocation
      ? (products as unknown as { locationId?: number; stock?: number; unitPrice?: string; isActive?: boolean }[])
          .filter(p => p.isActive !== false && p.locationId === selectedLocation.id)
          .reduce((s, p) => s + (p.stock ?? 0) * parseFloat(p.unitPrice ?? "0"), 0)
      : null;

  // CREDIT IN / OUTSTANDING: from filtered dashboard (by userId for non-admin)
  const creditIn    = dashboardRaw?.creditReceivable ? parseFloat(dashboardRaw.creditReceivable) : null;
  const outstanding = dashboardRaw?.creditPayable    ? parseFloat(dashboardRaw.creditPayable)    : null;

  // Grand total = bank + stock + credit receivable
  const grandTotal = (bankBal !== null || stockVal !== null || creditIn !== null)
    ? (bankBal ?? 0) + (stockVal ?? 0) + (creditIn ?? 0)
    : null;

  // ── Display helpers ────────────────────────────────────────────────────
  // Show only what the user has typed — no ghost trailing zeros
  const typedPart = amount;
  const ghostPart = "";

  const handleNumpad = (key: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    if (key === "⌫") { setAmount(prev => prev.length > 1 ? prev.slice(0, -1) : "0"); return; }
    if (key === ".") { if (!amount.includes(".")) setAmount(prev => prev + "."); return; }
    if (amount === "0") setAmount(key);
    else setAmount(prev => {
      if (prev.includes(".") && (prev.split(".")[1]?.length ?? 0) >= 8) return prev;
      if (prev.length >= 16) return prev;
      return prev + key;
    });
  };

  const handleCopyQty = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    try {
      await Clipboard.setStringAsync(String(qty));
      setCopiedQty(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      setTimeout(() => setCopiedQty(false), 2000);
    } catch {
      setCopyError(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
      setTimeout(() => setCopyError(false), 2000);
    }
  };

  const handleCompleteSale = async () => {
    if (!cashValidations.canComplete) {
      Alert.alert("Cannot Complete Sale", cashValidations.errors.map(e => `• ${e}`).join("\n"));
      return;
    }
    if (!user) return;
    try {
      await (createSaleMutation as unknown as { mutateAsync: (a: { data: unknown }) => Promise<unknown> }).mutateAsync({
        data: {
          userId: user.id,
          customerId: selectedCustomer?.id ?? null,
          accountId: selectedAccount!.id,
          locationId: selectedLocation?.id ?? user.locationId ?? null,
          items: [{ productId: selectedProduct!.id, qty, unitPrice: activePrice.toFixed(8) }],
          discount: "0.00000000", tax: "0.00000000",
          amountPaid: parsedAmount.toFixed(8),
          paymentMethod: "cash",
          notes: rateMode === "wholesale" ? "Wholesale rate" : null,
        },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      queryClient.invalidateQueries();
      setAmount("0");
      Alert.alert(
        "✓ Sale Complete",
        `${selectedProduct!.name}\nQTY: ${qty} ${selectedProduct!.unit}\nRate: ${rateMode === "wholesale" ? "Wholesale" : "Retail"} @ ${activePrice.toFixed(2)}\nPaid: ${parsedAmount.toFixed(2)}\nAccount: ${selectedAccount!.name}`,
        [{ text: "New Sale", onPress: () => { setSelectedProduct(null); setSelectedCustomer(null); } }, { text: "OK" }]
      );
    } catch (e: unknown) {
      Alert.alert("Sale Failed", e instanceof Error ? e.message : "Unexpected error");
    }
  };

  const handleCreditSale = async () => {
    if (!canCreditSale) {
      Alert.alert("Access Denied", "You do not have permission to make credit sales.");
      return;
    }
    if (!creditValidations.canComplete) {
      Alert.alert("Cannot Process Credit Sale", creditValidations.errors.map(e => `• ${e}`).join("\n"));
      return;
    }
    if (!user) return;
    try {
      await (createSaleMutation as unknown as { mutateAsync: (a: { data: unknown }) => Promise<unknown> }).mutateAsync({
        data: {
          userId: user.id,
          customerId: selectedCustomer!.id,
          accountId: selectedAccount?.id ?? null,
          locationId: selectedLocation?.id ?? user.locationId ?? null,
          items: [{ productId: selectedProduct!.id, qty, unitPrice: activePrice.toFixed(8) }],
          discount: "0.00000000", tax: "0.00000000",
          amountPaid: "0.00000000",
          paymentMethod: "credit",
          notes: rateMode === "wholesale" ? "Wholesale rate — credit" : "Credit sale",
        },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
      queryClient.invalidateQueries();
      setAmount("0");
      Alert.alert(
        "Credit Entry Added",
        `${selectedProduct!.name}\nQTY: ${qty} ${selectedProduct!.unit}\nTotal: ${parsedAmount.toFixed(2)}\nCustomer: ${selectedCustomer!.name}\n\nEntry saved to Credits.`,
        [{ text: "New Sale", onPress: () => { setSelectedProduct(null); setSelectedCustomer(null); } }, { text: "OK" }]
      );
    } catch (e: unknown) {
      Alert.alert("Credit Failed", e instanceof Error ? e.message : "Unexpected error");
    }
  };

  const stockWarning = selectedProduct && (selectedProduct.stock ?? 0) <= 0
    ? "out-of-stock"
    : selectedProduct && qty > (selectedProduct.stock ?? 0) && qty > 0
      ? "exceeds-stock" : null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <LinearGradient colors={[colors.headerBg, colors.primary]} style={[styles.header, { paddingTop: topPad + 8, justifyContent: "center" }]}>
        <Text style={[styles.headerTitle, { textAlign: "center", fontSize: 22, letterSpacing: 2 }]}>COINS DYNASTY</Text>
        <TouchableOpacity
          onPress={toggleStrictMode}
          activeOpacity={0.7}
          style={{
            position: "absolute", right: 16, bottom: 12,
            flexDirection: "row", alignItems: "center", gap: 4,
            paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10,
            borderWidth: 1,
            borderColor: strictMode ? "#FCA5A5" : "rgba(255,255,255,0.3)",
            backgroundColor: strictMode ? "rgba(220,38,38,0.2)" : "rgba(255,255,255,0.1)",
          }}
        >
          <Text style={{ fontSize: 10 }}>{strictMode ? "🔒" : "🔓"}</Text>
          <Text style={{ fontFamily: "Inter_700Bold", fontSize: 8, color: strictMode ? "#FECACA" : "rgba(255,255,255,0.65)", letterSpacing: 0.8 }}>
            {strictMode ? "STRICT" : "RELAXED"}
          </Text>
        </TouchableOpacity>
      </LinearGradient>

      {/* ── Location banner ─────────────────────────────────────────────── */}
      <TouchableOpacity
        style={[styles.locationBanner, {
          backgroundColor: selectedLocation ? "#ECFDF5" : colors.card,
          borderBottomColor: selectedLocation ? "#A7F3D0" : colors.border,
        }]}
        onPress={isAdmin ? () => setShowLocationModal(true) : undefined}
        activeOpacity={isAdmin ? 0.7 : 1}
      >
        <View style={[styles.locationIconWrap, { backgroundColor: selectedLocation ? "#059669" : colors.primary }]}>
          <Text style={{ fontSize: 13, color: "#FFF", lineHeight: 18 }}>
            {selectedLocation ? "◉" : "⊕"}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.locationBannerLabel, { color: colors.mutedForeground }]}>
            {isAdmin ? "ACTIVE APP" : "YOUR APP"}
          </Text>
          <Text style={[styles.locationBannerName, { color: selectedLocation ? "#065F46" : colors.primary }]}>
            {selectedLocation?.name ?? (isAdmin ? "Tap to select app" : "No app assigned")}
          </Text>
        </View>
        {selectedLocation ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            {selectedLocation.id !== defaults.locationId && (
              <TouchableOpacity
                onPress={e => { e.stopPropagation?.(); saveDefault("locationId", selectedLocation.id); }}
                style={{ backgroundColor: "#FEF3C7", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: "#FDE68A" }}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <Text style={{ fontFamily: "Inter_700Bold", fontSize: 10, color: "#92400E" }}>★ Set Default</Text>
              </TouchableOpacity>
            )}
            {selectedLocation.id === defaults.locationId && (
              <View style={{ backgroundColor: "#D1FAE5", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: "#A7F3D0" }}>
                <Text style={{ fontFamily: "Inter_700Bold", fontSize: 10, color: "#065F46" }}>★ Default</Text>
              </View>
            )}
            <View style={{ backgroundColor: "#D1FAE5", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: "#A7F3D0" }}>
              <Text style={{ fontFamily: "Inter_700Bold", fontSize: 11, color: "#065F46" }}>
                {isAdmin ? "ACTIVE ›" : "ASSIGNED"}
              </Text>
            </View>
          </View>
        ) : isAdmin ? (
          <View style={{ backgroundColor: colors.secondary, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, borderWidth: 1, borderColor: colors.border }}>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: colors.primary }}>›</Text>
          </View>
        ) : null}
      </TouchableOpacity>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>

        {/* ── Today / Yesterday / Compare strip (TOP) ───────────────── */}
        <View style={{ flexDirection: "row", gap: 8, marginHorizontal: 14, marginTop: 4, marginBottom: 0 }}>
          {/* Today */}
          <View style={{ flex: 1, backgroundColor: "#EFF6FF", borderRadius: 14, borderWidth: 1.5, borderColor: "#BFDBFE", paddingHorizontal: 11, paddingVertical: 9 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginBottom: 4 }}>
              <Text style={{ fontSize: 11 }}>☀️</Text>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 9, color: "#3B82F6", letterSpacing: 0.8, textTransform: "uppercase" }}>Today</Text>
              {todayCount !== null && (
                <View style={{ marginLeft: "auto", backgroundColor: "#DBEAFE", borderRadius: 5, paddingHorizontal: 4, paddingVertical: 1 }}>
                  <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: "#1D4ED8" }}>{todayCount}×</Text>
                </View>
              )}
            </View>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 8, color: "#93C5FD", letterSpacing: 0.3, marginBottom: 1 }}>₨</Text>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: "#1E3A8A", lineHeight: 21 }} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>
              {todaySales !== null ? Math.round(todaySales).toLocaleString() : "—"}
            </Text>
          </View>

          {/* Yesterday */}
          <View style={{ flex: 1, backgroundColor: "#F5F3FF", borderRadius: 14, borderWidth: 1.5, borderColor: "#DDD6FE", paddingHorizontal: 11, paddingVertical: 9 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginBottom: 4 }}>
              <Text style={{ fontSize: 11 }}>🌙</Text>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 9, color: "#8B5CF6", letterSpacing: 0.8, textTransform: "uppercase" }}>Yest.</Text>
              {yestCount !== null && (
                <View style={{ marginLeft: "auto", backgroundColor: "#EDE9FE", borderRadius: 5, paddingHorizontal: 4, paddingVertical: 1 }}>
                  <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: "#6D28D9" }}>{yestCount}×</Text>
                </View>
              )}
            </View>
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 8, color: "#C4B5FD", letterSpacing: 0.3, marginBottom: 1 }}>₨</Text>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 18, color: "#4C1D95", lineHeight: 21 }} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>
              {yestSales !== null ? Math.round(yestSales).toLocaleString() : "—"}
            </Text>
          </View>

          {/* Compare */}
          {salesDiff !== null ? (
            <View style={{
              width: 68, backgroundColor: salesDiff >= 0 ? "#ECFDF5" : "#FEF2F2",
              borderRadius: 14, borderWidth: 1.5,
              borderColor: salesDiff >= 0 ? "#6EE7B7" : "#FECACA",
              paddingHorizontal: 6, paddingVertical: 9,
              alignItems: "center", justifyContent: "center", gap: 2,
            }}>
              <Text style={{ fontSize: 17 }}>{salesDiff >= 0 ? "📈" : "📉"}</Text>
              {salesDiffPct !== null && (
                <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: salesDiff >= 0 ? "#065F46" : "#991B1B", lineHeight: 15 }}>
                  {salesDiff >= 0 ? "+" : ""}{Math.abs(salesDiffPct).toFixed(1)}%
                </Text>
              )}
              <Text style={{ fontFamily: "Inter_400Regular", fontSize: 8, color: salesDiff >= 0 ? "#059669" : "#DC2626" }} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>
                {salesDiff >= 0 ? "▲" : "▼"} {Math.abs(salesDiff) >= 1000 ? `${(Math.abs(salesDiff)/1000).toFixed(1)}K` : Math.abs(salesDiff).toFixed(0)}
              </Text>
            </View>
          ) : (
            <View style={{ width: 68, backgroundColor: colors.secondary, borderRadius: 14, borderWidth: 1.5, borderColor: colors.border, padding: 8, alignItems: "center", justifyContent: "center", gap: 3 }}>
              <Text style={{ fontSize: 16 }}>📊</Text>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 9, color: colors.mutedForeground, textAlign: "center" }}>vs prev</Text>
            </View>
          )}
        </View>

        {/* ── Grid divider line ──────────────────────────────────────── */}
        <View style={{ marginHorizontal: 14, marginVertical: 8, flexDirection: "row", alignItems: "center", gap: 6 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
          <View style={{ flexDirection: "row", gap: 3 }}>
            {[0,1,2,3].map(i => (
              <View key={i} style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
            ))}
          </View>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
        </View>

        {/* ── Balance tiles (BOTTOM) ─────────────────────────────────── */}
        <View style={[styles.balanceGrid, { marginTop: 0 }]}>
          <BalanceTile label="BANK" emoji="🏦" value={bankBal} color="#2563EB" accentBg="#EFF6FF" colors={colors} />
          <BalanceTile label="STOCK" emoji="📦" value={stockVal} color="#D97706" accentBg="#FFF7ED" colors={colors} />
          <BalanceTile label="CREDIT" emoji="📈" value={creditIn} color="#7C3AED" accentBg="#F3E8FF" colors={colors} />
          <BalanceTile label="TOTAL" emoji="💰" value={grandTotal} color="#059669" accentBg="#ECFDF5" colors={colors} isTotal />
        </View>

        {/* ── Product picker ───────────────────────────────────────────── */}
        {canSelectProduct ? (
          /* Admin / Manager — tap card to open full modal */
          <TouchableOpacity
            style={[styles.productCard, {
              backgroundColor: colors.card,
              borderColor: stockWarning === "out-of-stock" ? colors.danger
                : stockWarning === "exceeds-stock" ? "#F59E0B"
                : selectedProduct ? colors.primary : colors.border,
            }]}
            onPress={() => setShowProductModal(true)}
            activeOpacity={0.85}
          >
            <View style={{ flex: 1 }}>
              {selectedProduct ? (
                <>
                  {/* Row 1: dot + name + [Set Default] + [Stock] */}
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 5 }}>
                    <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: (selectedProduct.stock ?? 0) > 0 ? colors.success : colors.danger }} />
                    <Text style={[styles.productName, { color: colors.text, flex: 1, fontSize: 14 }]} numberOfLines={1}>{selectedProduct.name}</Text>
                    {selectedProduct.id !== defaults.productId ? (
                      <TouchableOpacity
                        onPress={e => { e.stopPropagation?.(); saveDefault("productId", selectedProduct.id); }}
                        style={{ backgroundColor: "#FEF3C7", paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7, borderWidth: 1, borderColor: "#FDE68A" }}
                        hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                      >
                        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 9, color: "#92400E" }}>★ Default</Text>
                      </TouchableOpacity>
                    ) : (
                      <View style={{ backgroundColor: "#DCFCE7", paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7, borderWidth: 1, borderColor: "#BBF7D0" }}>
                        <Text style={{ fontFamily: "Inter_700Bold", fontSize: 9, color: "#166534" }}>★ Default</Text>
                      </View>
                    )}
                    <View style={[styles.stockBadge, { backgroundColor: (selectedProduct.stock ?? 0) > 0 ? colors.saleBg : colors.dangerBg }]}>
                      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 9, color: (selectedProduct.stock ?? 0) > 0 ? colors.success : colors.danger }}>
                        {selectedProduct.stock ?? 0} {selectedProduct.unit}
                      </Text>
                    </View>
                  </View>
                  {/* Row 2: prices */}
                  <View style={{ flexDirection: "row", gap: 6 }}>
                    <View style={{ backgroundColor: colors.secondary, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 7 }}>
                      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 10, color: colors.primary }}>Retail {parseFloat(selectedProduct.unitPrice).toFixed(2)}</Text>
                    </View>
                    <View style={{ backgroundColor: colors.purchaseBg, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 7 }}>
                      <Text style={{ fontFamily: "Inter_500Medium", fontSize: 10, color: colors.purchase }}>WS {parseFloat(selectedProduct.wholesalePrice || selectedProduct.unitPrice).toFixed(2)}</Text>
                    </View>
                  </View>
                  {stockWarning === "out-of-stock" && (
                    <View style={[styles.alertRow, { backgroundColor: colors.dangerBg, marginTop: 5 }]}>
                      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 10, color: colors.danger }}>OUT OF STOCK — Cannot sell</Text>
                    </View>
                  )}
                  {stockWarning === "exceeds-stock" && (
                    <View style={[styles.alertRow, { backgroundColor: "#FEF3C7", marginTop: 5 }]}>
                      <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 10, color: "#D97706" }}>QTY {qty} exceeds stock of {selectedProduct.stock}</Text>
                    </View>
                  )}
                </>
              ) : (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                  <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: "#EFF6FF", alignItems: "center", justifyContent: "center" }}>
                    <Text style={{ fontSize: 24 }}>🛍️</Text>
                  </View>
                  <View>
                    <Text style={[styles.productPlaceholder, { color: colors.primary }]}>Tap to select product</Text>
                    <Text style={[styles.productSub, { color: colors.mutedForeground }]}>Required to begin sale</Text>
                  </View>
                </View>
              )}
            </View>
            <View style={[styles.productChevron, { backgroundColor: colors.secondary }]}>
              <Text style={{ fontSize: 16, color: colors.primary, fontFamily: "Inter_700Bold" }}>›</Text>
            </View>
          </TouchableOpacity>
        ) : (
          /* Cashier — quick-tap product icon chips */
          <View style={[styles.productCard, {
            backgroundColor: colors.card,
            borderColor: stockWarning === "out-of-stock" ? colors.danger
              : stockWarning === "exceeds-stock" ? "#F59E0B"
              : selectedProduct ? colors.primary : colors.border,
            flexDirection: "column", gap: 10,
          }]}>
            {/* Selected product info row */}
            {selectedProduct ? (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: (selectedProduct.stock ?? 0) > 0 ? colors.success : colors.danger }} />
                <Text style={[styles.productName, { color: colors.text, flex: 1 }]} numberOfLines={1}>{selectedProduct.name}</Text>
                <View style={[styles.stockBadge, { backgroundColor: (selectedProduct.stock ?? 0) > 0 ? colors.saleBg : colors.dangerBg }]}>
                  <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 10, color: (selectedProduct.stock ?? 0) > 0 ? colors.success : colors.danger }}>
                    Stock: {selectedProduct.stock ?? 0} {selectedProduct.unit}
                  </Text>
                </View>
                <View style={{ backgroundColor: colors.secondary, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 }}>
                  <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: colors.primary }}>
                    ₨{parseFloat(rateMode === "wholesale" ? (selectedProduct.wholesalePrice || selectedProduct.unitPrice) : selectedProduct.unitPrice).toFixed(0)}
                  </Text>
                </View>
              </View>
            ) : (
              <Text style={[styles.productPlaceholder, { color: colors.mutedForeground }]}>Select a product below</Text>
            )}

            {/* Product chip grid */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -4 }} contentContainerStyle={{ paddingHorizontal: 4, gap: 8, flexDirection: "row" }}>
              {activeProducts.map(p => {
                const isSelected = selectedProduct?.id === p.id;
                const inStock = (p.stock ?? 0) > 0;
                return (
                  <TouchableOpacity
                    key={p.id}
                    style={{
                      alignItems: "center", gap: 4,
                      paddingHorizontal: 12, paddingVertical: 9,
                      borderRadius: 14, borderWidth: 2,
                      backgroundColor: isSelected ? colors.primary : inStock ? colors.secondary : colors.dangerBg,
                      borderColor: isSelected ? colors.primary : inStock ? colors.border : colors.danger,
                      minWidth: 70,
                    }}
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
                      setSelectedProduct(p);
                      setRateMode("normal");
                    }}
                    activeOpacity={0.75}
                  >
                    {p.imageUrl ? (
                      <Image source={{ uri: p.imageUrl }} style={{ width: 36, height: 36, borderRadius: 10 }} />
                    ) : (
                      <Text style={{ fontSize: 20, lineHeight: 24 }}>{inStock ? "📦" : "🚫"}</Text>
                    )}
                    <Text style={{ fontFamily: "Inter_700Bold", fontSize: 11, color: isSelected ? "#FFF" : colors.text, textAlign: "center" }} numberOfLines={2}>
                      {p.name}
                    </Text>
                    <Text style={{ fontFamily: "Inter_500Medium", fontSize: 9, color: isSelected ? "rgba(255,255,255,0.8)" : inStock ? colors.success : colors.danger }}>
                      {inStock ? `${p.stock} ${p.unit}` : "OUT"}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            {/* Stock warnings */}
            {stockWarning === "out-of-stock" && (
              <View style={[styles.alertRow, { backgroundColor: colors.dangerBg }]}>
                
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: colors.danger }}>OUT OF STOCK — Cannot sell</Text>
              </View>
            )}
            {stockWarning === "exceeds-stock" && (
              <View style={[styles.alertRow, { backgroundColor: "#FEF3C7" }]}>
                
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: "#D97706" }}>QTY {qty} exceeds stock of {selectedProduct?.stock}</Text>
              </View>
            )}
          </View>
        )}

        {/* ── Rate toggle ──────────────────────────────────────────────── */}
        {selectedProduct && (
          <View style={[styles.rateToggle, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TouchableOpacity
              style={[styles.rateBtn, rateMode === "normal" && { backgroundColor: colors.primary }]}
              onPress={() => { setRateMode("normal"); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {}); }}
            >
              
              <Text style={[styles.rateBtnText, { color: rateMode === "normal" ? "#FFF" : colors.mutedForeground }]}>
                Retail {parseFloat(selectedProduct.unitPrice).toFixed(2)}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.rateBtn, rateMode === "wholesale" && { backgroundColor: colors.purchase }]}
              onPress={() => { setRateMode("wholesale"); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {}); }}
            >
              
              <Text style={[styles.rateBtnText, { color: rateMode === "wholesale" ? "#FFF" : colors.mutedForeground }]}>
                Wholesale {parseFloat(selectedProduct.wholesalePrice || selectedProduct.unitPrice).toFixed(2)}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── Amount | QTY | Copy — 3 separate colorful cards ────────── */}
        <View style={{ flexDirection: "row", gap: 7, marginHorizontal: 14, marginTop: 6 }}>

          {/* 💵 AMOUNT card — blue */}
          <View style={{ flex: 1.1, backgroundColor: "#EFF6FF", borderRadius: 14, borderWidth: 2, borderColor: "#93C5FD", paddingHorizontal: 11, paddingVertical: 9 }}>
            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: "#3B82F6", letterSpacing: 0.9, marginBottom: 2 }}>💵 AMOUNT</Text>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 22, color: "#1E40AF", lineHeight: 26 }} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>
              {typedPart}<Text style={{ color: "#93C5FD", opacity: 0.6 }}>{ghostPart}</Text>
            </Text>
          </View>

          {/* 📦 QTY card — green */}
          <View style={{
            flex: 1,
            backgroundColor: stockWarning ? "#FEF2F2" : "#ECFDF5",
            borderRadius: 14, borderWidth: 2,
            borderColor: stockWarning ? "#FCA5A5" : "#6EE7B7",
            paddingHorizontal: 10, paddingVertical: 9,
          }}>
            <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: stockWarning ? "#EF4444" : "#059669", letterSpacing: 0.9, marginBottom: 2 }}>
              {stockWarning ? "⚠️ QTY" : "📦 QTY"}{selectedProduct ? ` @ ${activePrice.toFixed(0)}` : ""}
            </Text>
            <Text style={{ fontFamily: "Inter_700Bold", fontSize: 22, color: stockWarning ? "#DC2626" : qty > 0 ? "#065F46" : "#A7F3D0", lineHeight: 26 }}>
              {qty > 0 ? qty.toLocaleString() : "—"}
            </Text>
            {stockWarning === "exceeds-stock" && selectedProduct && (
              <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 8, color: "#EF4444", marginTop: 1 }}>Max {selectedProduct.stock} {selectedProduct.unit}</Text>
            )}
            {stockWarning === "out-of-stock" && (
              <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 8, color: "#EF4444", marginTop: 1 }}>Out of stock</Text>
            )}
          </View>

          {/* 📋 COPY card — indigo */}
          <TouchableOpacity
            style={{
              backgroundColor: copyError ? "#FEF2F2" : copiedQty ? "#ECFDF5" : "#EEF2FF",
              borderRadius: 14, borderWidth: 2,
              borderColor: copyError ? "#FCA5A5" : copiedQty ? "#6EE7B7" : "#A5B4FC",
              paddingHorizontal: 10, paddingVertical: 9,
              alignItems: "center", justifyContent: "center", gap: 3,
              opacity: qty <= 0 ? 0.4 : 1,
            }}
            onPress={handleCopyQty} disabled={qty <= 0}
            activeOpacity={0.7}
          >
            <Text style={{ fontSize: 18 }}>{copyError ? "⚠️" : copiedQty ? "✅" : "📋"}</Text>
            <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 9, color: copyError ? "#B91C1C" : copiedQty ? "#065F46" : "#3730A3", textAlign: "center" }}>
              {copyError ? "Error" : copiedQty ? "Copied!" : "Copy\nQTY"}
            </Text>
          </TouchableOpacity>

        </View>

        {/* ── Quick preset amounts ─────────────────────────────────────── */}
        <View style={[styles.displayCard, { backgroundColor: colors.card, borderColor: colors.border, overflow: "hidden" }]}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexDirection: "row", gap: 7, paddingHorizontal: 10, paddingVertical: 9 }}>
            {([
              { v: 100,  label: "100",  bg: "#FEF3C7", border: "#F59E0B", text: "#92400E" },
              { v: 200,  label: "200",  bg: "#FCE7F3", border: "#EC4899", text: "#831843" },
              { v: 300,  label: "300",  bg: "#EDE9FE", border: "#8B5CF6", text: "#4C1D95" },
              { v: 500,  label: "500",  bg: "#DBEAFE", border: "#3B82F6", text: "#1E3A8A" },
              { v: 1000, label: "1K",   bg: "#E0E7FF", border: "#6366F1", text: "#312E81" },
              { v: 1500, label: "1.5K", bg: "#FEE2E2", border: "#EF4444", text: "#7F1D1D" },
              { v: 5000, label: "5K",   bg: "#D1FAE5", border: "#10B981", text: "#064E3B" },
            ] as const).map(({ v, label, bg, border, text }) => {
              const isSelected = parseFloat(amount) === v;
              return (
                <TouchableOpacity
                  key={v}
                  style={{
                    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5,
                    backgroundColor: isSelected ? border : bg,
                    borderColor: border,
                    minWidth: 52, alignItems: "center",
                  }}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
                    setAmount(String(v));
                  }}
                >
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 13, color: isSelected ? "#FFF" : text }}>
                    {label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* ── Customer + Account — same single row ─────────────────────── */}
        <View style={[styles.optionsCard, { backgroundColor: colors.card, borderColor: colors.border, flexDirection: "row" }]}>

          {/* Customer half */}
          {canCreditSale && (
            <>
              <TouchableOpacity
                style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 10, paddingVertical: 9 }}
                onPress={() => setShowCustomerModal(true)}
                activeOpacity={0.7}
              >
                <View style={[styles.optionIcon, { backgroundColor: selectedCustomer ? "#FEF3C7" : colors.secondary }]}>
                  <Text style={{ fontSize: 13 }}>{selectedCustomer ? "👤" : "👥"}</Text>
                </View>
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: colors.mutedForeground, letterSpacing: 0.6 }}>CUSTOMER</Text>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 12, color: selectedCustomer ? colors.text : colors.mutedForeground }} numberOfLines={1}>
                    {selectedCustomer?.name ?? "Walk-in"}
                  </Text>
                  {selectedCustomer?.creditBalance && parseFloat(selectedCustomer.creditBalance) > 0 && (
                    <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: colors.danger }}>
                      Outstanding: ₨{parseFloat(selectedCustomer.creditBalance).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </Text>
                  )}
                </View>
                <Text style={{ fontSize: 13, color: colors.mutedForeground }}>›</Text>
              </TouchableOpacity>
              {/* Vertical divider */}
              <View style={{ width: 1, backgroundColor: colors.border }} />
            </>
          )}

          {/* Account half */}
          <TouchableOpacity
            style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 10, paddingVertical: 9 }}
            onPress={() => {
              if (!canSelectAccount) {
                Alert.alert("Access Denied", "You don't have permission to change the payment account.");
                return;
              }
              setShowAccountModal(true);
            }}
            activeOpacity={0.7}
          >
            {(() => {
              const ac = selectedAccount ? acctColor(selectedAccount.type) : null;
              return (
                <View style={[styles.optionIcon, {
                  backgroundColor: ac ? ac.bg : (canSelectAccount ? colors.dangerBg : colors.input),
                  borderWidth: ac ? 1 : 0, borderColor: ac?.border,
                }]}>
                  <Text style={{ fontSize: 13 }}>{selectedAccount ? acctEmoji(selectedAccount.type) : "🏧"}</Text>
                </View>
              );
            })()}
            <View style={{ flex: 1, minWidth: 0 }}>
              <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: colors.mutedForeground, letterSpacing: 0.6 }}>ACCOUNT</Text>
              {selectedAccount ? (
                <>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 12, color: colors.text }} numberOfLines={1}>{selectedAccount.name}</Text>
                  <Text style={{ fontFamily: "Inter_500Medium", fontSize: 8, color: colors.mutedForeground }}>
                    ₨{parseFloat(selectedAccount.balance).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </Text>
                </>
              ) : (
                <Text style={{ fontFamily: "Inter_600SemiBold", fontSize: 11, color: canSelectAccount ? colors.danger : colors.mutedForeground }}>
                  {canSelectAccount ? "Tap to select" : "Locked"}
                </Text>
              )}
            </View>
            {selectedAccount && (
              selectedAccount.id !== defaults.accountId ? (
                <TouchableOpacity
                  onPress={e => { e.stopPropagation?.(); saveDefault("accountId", selectedAccount.id); }}
                  style={{ backgroundColor: "#FEF3C7", paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5, borderWidth: 1, borderColor: "#FDE68A" }}
                  hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                >
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 8, color: "#92400E" }}>★</Text>
                </TouchableOpacity>
              ) : (
                <View style={{ backgroundColor: "#DCFCE7", paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5, borderWidth: 1, borderColor: "#BBF7D0" }}>
                  <Text style={{ fontFamily: "Inter_700Bold", fontSize: 8, color: "#166534" }}>★</Text>
                </View>
              )
            )}
            <Text style={{ fontSize: 13, color: colors.mutedForeground }}>›</Text>
          </TouchableOpacity>
        </View>

        {/* ── Numpad ──────────────────────────────────────────────────── */}
        <View style={[styles.numpadContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {NUMPAD_KEYS.map((row, ri) => (
            <View key={ri} style={styles.numpadRow}>
              {row.map(key => (
                <TouchableOpacity
                  key={key}
                  style={[styles.numpadKey, {
                    backgroundColor: key === "⌫" ? colors.numpadDelete : key === "." ? colors.secondary : colors.numpadKey,
                    borderColor: colors.border,
                  }]}
                  onPress={() => handleNumpad(key)}
                  activeOpacity={0.6}
                >
                  {key === "⌫"
                    ? null
                    : <Text style={[styles.numpadKeyText, { color: key === "." ? colors.primary : colors.numpadKeyText }]}>{key}</Text>}
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>

        {/* ── Action buttons ───────────────────────────────────────────── */}
        <View style={styles.actionsRow}>
          <TouchableOpacity
            style={[styles.clearBtn, { backgroundColor: colors.numpadDelete }]}
            onPress={() => { setAmount("0"); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {}); }}
          >
            
          </TouchableOpacity>

          {canCreditSale && (
            <TouchableOpacity
              style={[styles.creditBtn, {
                backgroundColor: creditValidations.canComplete ? colors.credit : colors.mutedForeground,
                opacity: (createSaleMutation.isPending || (strictMode && !creditValidations.canComplete)) ? 0.5 : 1,
              }]}
              onPress={handleCreditSale}
              disabled={createSaleMutation.isPending || (strictMode && !creditValidations.canComplete)}
            >
              
              <Text style={styles.actionBtnText}>Credit</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity
            style={[styles.completeBtn, {
              backgroundColor: cashValidations.canComplete ? colors.success : colors.mutedForeground,
              opacity: (createSaleMutation.isPending || (strictMode && !cashValidations.canComplete)) ? 0.5 : 1,
              flex: canCreditSale ? 2 : 3,
            }]}
            onPress={handleCompleteSale}
            disabled={createSaleMutation.isPending || (strictMode && !cashValidations.canComplete)}
          >
            {createSaleMutation.isPending
              ? <Text style={styles.actionBtnText}>Processing...</Text>
              : <><Text style={styles.actionBtnText}>Complete Sale</Text></>}
          </TouchableOpacity>
        </View>

        {/* ── My Target Progress (each user sees only their own) ─────────── */}
        {myTargetProgress ? (
          <View style={[styles.targetWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.targetHeader}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.targetHeaderTitle, { color: colors.foreground }]} numberOfLines={1}>
                  🎯 {myTargetProgress.title}
                </Text>
                <Text style={[styles.targetHeaderSub, { color: colors.mutedForeground }]} numberOfLines={1}>
                  {myTargetProgress.type === "weekly" ? "Weekly" : "Daily"} · Target ₨{formatK(parseFloat(myTargetProgress.targetAmount))} · {myTargetProgress.commissionType === "percentage"
                    ? `${parseFloat(myTargetProgress.commissionValue).toFixed(1)}% commission`
                    : `flat ₨${formatK(parseFloat(myTargetProgress.commissionValue))} bonus`}
                </Text>
              </View>
            </View>

            {/* Progress bar */}
            <View style={styles.progressBarTrack}>
              <View style={[styles.progressBarFill, {
                width: `${Math.min(100, parseFloat(myTargetProgress.achievedPct))}%`,
                backgroundColor: parseFloat(myTargetProgress.achievedPct) >= 100 ? "#16A34A" : "#2563EB",
              }]} />
            </View>

            <View style={styles.targetTilesRow}>
              {/* Tile 1 — Target Achieved % */}
              <View style={[styles.targetTile, { backgroundColor: "#EFF6FF", borderColor: "#BFDBFE" }]}>
                <Text style={[styles.targetTileLabel, { color: "#1E40AF" }]}>TARGET %</Text>
                <Text style={[styles.targetTileValue, { color: "#1E3A8A" }]}>
                  {parseFloat(myTargetProgress.achievedPct).toFixed(0)}%
                </Text>
                <Text style={[styles.targetTileSub, { color: "#3730A3" }]} numberOfLines={1}>
                  ₨{formatK(parseFloat(myTargetProgress.achievedAmount))}
                </Text>
              </View>

              {/* Tile 2 — Bonus Earned */}
              <View style={[styles.targetTile, { backgroundColor: "#F0FDF4", borderColor: "#86EFAC" }]}>
                <Text style={[styles.targetTileLabel, { color: "#065F46" }]}>BONUS EARNED</Text>
                <Text style={[styles.targetTileValue, { color: "#064E3B" }]}>
                  ₨{formatK(parseFloat(myTargetProgress.earnedBonus))}
                </Text>
                <Text style={[styles.targetTileSub, { color: "#065F46" }]} numberOfLines={1}>
                  so far
                </Text>
              </View>

              {/* Tile 3 — Left Balance Bonus */}
              <View style={[styles.targetTile, { backgroundColor: "#FFFBEB", borderColor: "#FCD34D" }]}>
                <Text style={[styles.targetTileLabel, { color: "#92400E" }]}>LEFT BONUS</Text>
                <Text style={[styles.targetTileValue, { color: "#78350F" }]}>
                  ₨{formatK(parseFloat(myTargetProgress.leftBonus))}
                </Text>
                <Text style={[styles.targetTileSub, { color: "#92400E" }]} numberOfLines={1}>
                  still possible
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={[styles.noTargetBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={styles.noTargetEmoji}>🎯</Text>
            <View style={{ flex: 1 }}>
              <Text style={[styles.noTargetText, { color: colors.foreground }]}>No active target assigned</Text>
              <Text style={[styles.noTargetSub, { color: colors.mutedForeground }]}>
                {isAdmin ? "Set a sales target with bonus from the Targets screen" : "Ask your admin to set a sales target with bonus"}
              </Text>
            </View>
          </View>
        )}

        {/* ── Privilege notice ────────────────────────────────────────── */}
        {(!canCreditSale || allowedProductIds !== null || allowedAccountIds !== null || allowedLocationIds !== null) && (
          <View style={[styles.privNotice, { backgroundColor: "#FFF7ED", borderColor: "#FED7AA" }]}>
            
            <Text style={{ fontFamily: "Inter_400Regular", fontSize: 12, color: "#92400E", flex: 1 }}>
              {allowedProductIds !== null
                ? `Products: ${activeProducts.length} allowed. `
                : ""}
              {allowedLocationIds !== null
                ? `Locations: ${allowedLocations.length} allowed. `
                : ""}
              {allowedAccountIds !== null
                ? `Accounts: ${allowedAccounts.length} allowed. `
                : ""}
              {!canCreditSale ? "Credit sales disabled." : ""}
            </Text>
          </View>
        )}

      </ScrollView>

      <ProductPickerModal
        visible={showProductModal}
        products={activeProducts}
        allProducts={allActiveProducts}
        locations={allowedLocations}
        onSelect={p => { setSelectedProduct(p); setRateMode("normal"); }}
        onClose={() => setShowProductModal(false)}
      />
      <CustomerPickerModal
        visible={showCustomerModal} customers={customers} locations={allowedLocations}
        onSelect={setSelectedCustomer} onClose={() => setShowCustomerModal(false)}
      />
      <AccountPickerModal
        visible={showAccountModal} accounts={allowedAccounts}
        onSelect={setSelectedAccount} onClose={() => setShowAccountModal(false)}
      />
      <LocationPickerModal
        visible={showLocationModal} locations={allowedLocations}
        onSelect={setSelectedLocation} onClose={() => setShowLocationModal(false)}
      />
    </View>
  );
}

function BalanceTile({
  label, emoji, value, color, accentBg, colors, isTotal,
}: {
  label: string; emoji: string; value: number | null;
  color: string; accentBg: string; isTotal?: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  return (
    <View style={[
      styles.balanceTile,
      {
        backgroundColor: colors.card,
        borderColor: isTotal ? color : colors.border,
        borderWidth: isTotal ? 1.5 : 1,
      }
    ]}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 5 }}>
        <View style={[styles.balanceIconWrap, { backgroundColor: accentBg }]}>
          <Text style={{ fontSize: 14, lineHeight: 18 }}>{emoji}</Text>
        </View>
        <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>{label}</Text>
      </View>
      <Text
        style={[styles.balanceValue, { color: value !== null ? color : colors.mutedForeground, fontSize: isTotal ? 15 : 14 }]}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        {value !== null ? value.toLocaleString(undefined, { maximumFractionDigits: 0 }) : "—"}
      </Text>
      {isTotal && (
        <View style={{ height: 3, borderRadius: 2, backgroundColor: color, marginTop: 5, opacity: 0.5 }} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", paddingHorizontal: 20, paddingBottom: 14 },
  headerTitle: { fontFamily: "Inter_700Bold", fontSize: 20, color: "#FFFFFF", letterSpacing: 1 },
  headerSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: "rgba(255,255,255,0.7)" },
  headerRight: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  logoCircle: { width: 46, height: 46, borderRadius: 23, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", borderWidth: 2.5, borderColor: "rgba(255,255,255,0.6)", shadowColor: "#1E3A8A", shadowOpacity: 0.35, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 6 },
  logoText: { fontFamily: "Inter_700Bold", fontSize: 24, color: "#1E40AF", lineHeight: 30, marginTop: -1 },
  madeBy: { fontFamily: "Inter_400Regular", fontSize: 9, color: "rgba(255,255,255,0.55)", letterSpacing: 0.3 },
  dollarBadge: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#FFFFFF", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  dollarUsd: { fontFamily: "Inter_700Bold", fontSize: 11, color: "#0891B2", lineHeight: 14 },
  dollarPkr: { fontFamily: "Inter_400Regular", fontSize: 10, color: "#475569", lineHeight: 13 },
  userBadge: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#FFFFFF", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  // Location banner
  locationBanner: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 7, borderBottomWidth: 1 },
  locationIconWrap: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  locationBannerLabel: { fontFamily: "Inter_500Medium", fontSize: 8, letterSpacing: 0.8 },
  locationBannerName: { fontFamily: "Inter_700Bold", fontSize: 13, marginTop: 0 },
  // Balance tiles
  balanceGrid: { marginHorizontal: 12, marginTop: 12, flexDirection: "row", gap: 7 },
  balanceTile: { flex: 1, paddingVertical: 10, paddingHorizontal: 8, borderRadius: 13, borderWidth: 1 },
  balanceTileFirst: {},
  balanceIconWrap: { width: 24, height: 24, borderRadius: 7, alignItems: "center", justifyContent: "center" },
  balanceLabel: { fontFamily: "Inter_600SemiBold", fontSize: 8, letterSpacing: 0.5 },
  balanceValue: { fontFamily: "Inter_700Bold", fontSize: 13 },
  balSep: { width: 1, marginVertical: 12 },
  // Product
  productCard: { marginHorizontal: 14, marginTop: 6, borderRadius: 14, borderWidth: 2, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  productName: { fontFamily: "Inter_700Bold", fontSize: 14 },
  productPlaceholder: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  productSub: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 2 },
  productChevron: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  stockBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 7 },
  alertRow: { flexDirection: "row", alignItems: "center", gap: 5, padding: 6, borderRadius: 7 },
  // Rate toggle
  rateToggle: { marginHorizontal: 14, marginTop: 6, borderRadius: 12, borderWidth: 1, flexDirection: "row", padding: 3, gap: 3 },
  rateBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingVertical: 7, borderRadius: 10 },
  rateBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  // Display
  displayCard: { marginHorizontal: 14, marginTop: 8, borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  amountSection: { padding: 16, paddingBottom: 12 },
  amountLabel: { fontFamily: "Inter_500Medium", fontSize: 10, letterSpacing: 1, marginBottom: 4 },
  amountValue: { fontFamily: "Inter_700Bold", fontSize: 26, letterSpacing: -0.5 },
  divider: { height: 1 },
  qtySection: { padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  qtyLabel: { fontFamily: "Inter_500Medium", fontSize: 10, letterSpacing: 1, marginBottom: 4 },
  qtyValue: { fontFamily: "Inter_700Bold", fontSize: 44, lineHeight: 52 },
  copyBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1.5 },
  // Quick presets
  presetRow: { marginHorizontal: 14, marginTop: 8, borderRadius: 14, borderWidth: 1, padding: 12, gap: 8 },
  presetLabel: { fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 0.8 },
  presetBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: "center", borderWidth: 1.5 },
  presetBtnText: { fontFamily: "Inter_700Bold", fontSize: 14 },
  copyText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  // Options
  optionsCard: { marginHorizontal: 14, marginTop: 8, borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  optionRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 10, gap: 9, borderBottomWidth: 1 },
  optionIcon: { width: 24, height: 24, borderRadius: 7, alignItems: "center", justifyContent: "center" },
  optionLabel: { fontFamily: "Inter_500Medium", fontSize: 12, width: 66 },
  optionValue: { flex: 1, fontFamily: "Inter_600SemiBold", fontSize: 12, textAlign: "right", marginRight: 4 },
  balBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  // Numpad
  numpadContainer: { marginHorizontal: 14, marginTop: 8, borderRadius: 16, borderWidth: 1, padding: 10, gap: 8 },
  numpadRow: { flexDirection: "row", gap: 8 },
  numpadKey: { flex: 1, borderRadius: 12, borderWidth: 1, height: 56, alignItems: "center", justifyContent: "center" },
  numpadKeyText: { fontFamily: "Inter_700Bold", fontSize: 20 },
  // Actions
  actionsRow: { marginHorizontal: 14, marginTop: 10, flexDirection: "row", gap: 8 },
  clearBtn: { width: 52, height: 56, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  creditBtn: { flex: 1, height: 56, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  completeBtn: { height: 56, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  actionBtnText: { fontFamily: "Inter_700Bold", fontSize: 15, color: "#FFFFFF" },
  // Validation
  targetWrap: { marginHorizontal: 14, marginTop: 10, borderRadius: 14, borderWidth: 1, padding: 12, gap: 10 },
  targetHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  targetHeaderTitle: { fontFamily: "Inter_700Bold", fontSize: 13 },
  targetHeaderSub: { fontFamily: "Inter_500Medium", fontSize: 10, marginTop: 1 },
  progressBarTrack: { height: 6, borderRadius: 4, backgroundColor: "#E5E7EB", overflow: "hidden" },
  progressBarFill: { height: "100%", borderRadius: 4 },
  targetTilesRow: { flexDirection: "row", gap: 6 },
  targetTile: { flex: 1, borderRadius: 10, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 8, alignItems: "center" },
  targetTileLabel: { fontFamily: "Inter_700Bold", fontSize: 8, letterSpacing: 0.6, marginBottom: 3 },
  targetTileValue: { fontFamily: "Inter_700Bold", fontSize: 16 },
  targetTileSub: { fontFamily: "Inter_500Medium", fontSize: 9, marginTop: 2 },
  noTargetBox: { marginHorizontal: 14, marginTop: 10, borderRadius: 14, borderWidth: 1, padding: 12, flexDirection: "row", alignItems: "center", gap: 12 },
  noTargetEmoji: { fontSize: 22 },
  noTargetText: { fontFamily: "Inter_700Bold", fontSize: 12 },
  noTargetSub: { fontFamily: "Inter_400Regular", fontSize: 10, marginTop: 1 },
  // Priv notice
  privNotice: { marginHorizontal: 14, marginTop: 8, borderRadius: 12, borderWidth: 1, padding: 12, flexDirection: "row", alignItems: "flex-start", gap: 8 },
});
